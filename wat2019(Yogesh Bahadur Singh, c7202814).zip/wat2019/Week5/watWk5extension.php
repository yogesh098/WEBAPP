<h1>Order Form</h1>
<p>Please fill out this form to place your order.</p>
<form method="POST" action="">
    <fieldset>
<legend>Enter your login details</legend>
<label for="Username">User Name:</label>
<input type="text" name="username" value="<?php if(isset($_POST['username'])){ echo $_POST['username'];} ?>" />
<label for="Email">Email:</label>
<input type="text" name="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email'];} ?>" />
</fieldset>
<fieldset>
    <legend>Pizza Selection</legend>
    <label for="size">Size:</label>
    <input type="radio" name="size" value="Small"<?php if (isset($_POST['size']) && $_POST['size']=="Small") echo "checked";?>/>Small
    <input type="radio" name="size" value="Medium"<?php if (isset($_POST['size']) && $_POST['size']=="Medium") echo "checked";?>/>Medium
    <input type="radio" name="size" value="Large"<?php if (isset($_POST['size']) && $_POST['size']=="Large") echo "checked";?>/>Large<br>
    <label for ="Topping">Topping:</label>

    <select name="topping">
        <option value="Please Select">Please Select</option>
        <option value="Pepperoni"<?php echo (isset($_POST['topping']) && $_POST['topping']=="Pepperoni") ? 'selected="selected"' : '';?>>Pepperoni</option>
        <option value="Mushrooms"<?php echo (isset($_POST['topping']) && $_POST['topping']=="Mushrooms") ? 'selected="selected"' : '';?>>Mushrooms</option>
        <option value="Sausage"<?php echo (isset($_POST['topping']) && $_POST['topping']=="Sausage") ? 'selected="selected"' : '';?>>Sausage</option>
        <option value="Bacon"<?php echo (isset($_POST['topping']) && $_POST['topping']=="Bacon") ? 'selected="selected"' : '';?>>Bacon</option>
        <option value="Extra Cheese"<?php echo (isset($_POST['topping']) && $_POST['topping']=="Extra Cheese") ? 'selected="selected"' : '';?>>Extra Cheese</option>
</select>
<br/>
<label for="extras">Extras:</label>
<input type="checkbox" name="toppin[]" value="Parmesan" <?php if(isset($_POST['toppin']) && in_array("Parmesan", $_POST['toppin'])) echo "checked"; ?>/>Parmesan
<input type="checkbox" name="toppin[]" value="Olives" <?php if(isset($_POST['toppin']) && in_array("Olives", $_POST['toppin'])) echo "checked"; ?>/>Olives
<input type="checkbox" name="toppin[]" value="Capers" <?php if(isset($_POST['toppin']) && in_array("Capers", $_POST['toppin'])) echo "checked"; ?>/>Capers
</fieldset>
<input type="submit" name="submit" value="Submit" />
<input type="reset" value="Clear"/>
</form>
<?php
if(isset($_POST['submit'])){
if(isset($_POST['username'])&&isset($_POST['email'])&&isset($_POST['size'])&&($_POST['topping']!="Please Select")&&isset($_POST['toppin'])){
    $user = $_POST['username'];
    $email = $_POST['email'];
    $size = $_POST['size'];
    $selected_toppin =$_POST['topping'];
    echo"<h2>Thank you for your order:</h2>";
    echo"Customer ID: $user <br/>";
    echo"Email: $email <br/>";
    echo"Your Order: $size $selected_toppin <br/>";
    echo"Extra Toppings:";
    foreach($_POST['toppin'] as $value){
    echo " $value";
}
}
else{
    echo"All Fields Required";
}
}
?>