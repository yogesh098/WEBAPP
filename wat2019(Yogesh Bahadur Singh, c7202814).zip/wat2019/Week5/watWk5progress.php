<!DOCTYPE html> 
<html>  
    <head>
        <title>WAT Week 5 Progress Check</title>
    </head>  
    <body>   
        <h1>WAT Week 5 Progress Check</h1>   
        <h2>Generate Statements</h2>   
        <?php  
        echo"Yogesh Bahadur Singh <br/> C7202814 <br/>";
        echo("\"It's not more than £3\"");
        ?> 
        <h2>Use Arithmetic Operators </h2>   
        <?php   
        $loan = 500;
        $rate = 3.5;
        $interest = ($loan/100)*$rate;
        echo"Loan: $loan<br/>Rate: $rate%<br/>Payable: £$interest<br/>";
        ?>   
        <h2>Use Conditional Statements</h2>   
        <?php 
        $user = "user01";
        $pass = "pass";
        echo"Username: $user <br/>Password: $pass <br/>";
        if(strlen($pass)>6){
            if($user=="user01"&&$pass=="passwd"){
                echo"success";
            }
            else echo"fail";
            }
        else{
            echo"Please use at least 6 characters";            
        }
        ?>  
        </body> 
        </html>