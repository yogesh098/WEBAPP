<?php
$host="sql107.epizy.com";
$db="epiz_24847347_c7202814";
$u="epiz_24847347";
$p="I2jMMmDpu3z";
$conn=mysqli_connect($host,$u,$p,$db)
or die("Error while connecting database");
?>