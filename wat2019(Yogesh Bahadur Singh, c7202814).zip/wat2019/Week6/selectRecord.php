<?php
//Make connection to database
include 'connection.php';
//Display heading
echo '<h2>Select ALL from the Customer Table</h2>';
//run query to select all records from customer table
$query="SELECT * FROM customer";
//store the result of the query in a variable called $result
$result=mysqli_query($conn, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
while ($row=mysqli_fetch_assoc($result)){
echo $row['firstname'].' '.$row['lastname'].'
'.$row['email'].'<br />';
}

echo '<h2>Select all from the Customer Table with Age>22</h2>';

$query="SELECT * FROM customer where age>22";
//store the result of the query in a variable called $result
$result=mysqli_query($conn, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
while ($row=mysqli_fetch_assoc($result)){
echo $row['firstname'].' '.$row['lastname'].'
'.$row['email'].' '.$row['age'].'<br />';
}

echo '<h2>Select Females from the Customer Table with Age>=22</h2>';
$query="SELECT * FROM customer where gender='F' and age>=22";
//store the result of the query in a variable called $result
$result=mysqli_query($conn, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
while ($row=mysqli_fetch_assoc($result)){
echo $row['firstname'].' '.$row['lastname'].'
'.$row['email'].' '.$row['age'].'<br />';
}

echo '<h2>Select Malescfrom the Customer Table list by age descending</h2>';
$query="SELECT * FROM customer where gender='M' order by age DESC ";
//store the result of the query in a variable called $result
$result=mysqli_query($conn, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
while ($row=mysqli_fetch_assoc($result)){
echo $row['firstname'].' '.$row['lastname'].'
'.$row['email'].' '.$row['age'].'<br />';
}
echo '<h2>Select all with "a" in first name</h2>';

$query="SELECT * FROM customer where firstname like '%a%'";

$result=mysqli_query($conn, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
while ($row=mysqli_fetch_assoc($result)){
echo $row['firstname'].' '.$row['lastname'].' '.$row['email'].' '.$row['age'].'<br />';
}
?>