<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="POST" action="insertRecord.php">
<fieldset>
        <legend>
            Enter Customer Details
        </legend>

    <label for="firstname">First Name: </label>

    <input type="text" value="" name="fn"><br/>

    <label for="lastname">Last Name: </label>
<input type="text" value="" name="ln">
    <br/>
        <label for="email">Email: </label>
<input type="text" value="" name="e">
        <br/>
        <label for="password">Password: </label>
        <input type="text" value="" name="pass"><br/>
        <label for="gender">Gender: </label>
        <select name="gender">
            <option value="M">Male</option>
            <option value="F">Female</option>
        </select><br/>

        <label for="age">Age: </label>
    <input type="number" value="" name="age"></br>

       
        <input type="submit" value="Submit" name="loginSubmit"  />
        
    </fieldset>
</form>

<?php
include 'selectRecord.php';
?>
</body>
</html>