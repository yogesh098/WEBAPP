<?php
//Make connection to database
include 'connection.php';
//(a)Gather from $_POST[]all the data submitted and store in variables
if(isset($_POST['loginSubmit'])){
   $fn=$_POST['fn'];
   $ln=$_POST['ln'];
   $e=$_POST['e'];
   $pass=$_POST['pass'];
   $gender=$_POST['gender'];
   $age=$_POST['age'];
       }
    $query="INSERT INTO customer (firstName,lastName,email,password,gender,age) VALUES ('$fn', '$ln','$e','$pass','$gender','$age')"; 
    $qry=mysqli_query($conn, $query);
   if($qry){
   	echo"Row inserted";
   }

   else{
   	echo"Error inserting row";
   }
?>