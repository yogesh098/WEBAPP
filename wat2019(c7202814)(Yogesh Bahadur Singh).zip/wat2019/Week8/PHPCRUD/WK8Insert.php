<?php 
error_reporting(E_ALL); 
include '../Week6/connection.php'; 
if (isset($_POST['submit'])){  
$name=$_POST['eventName'];  
$pass=$_POST['eventCategory'];      
$query="INSERT INTO event   (eventName,eventCategory)  VALUES  ('$name','$pass')";    
mysqli_query($connection, $query);    
header('location:Wk8Recap.php');   
} ?>