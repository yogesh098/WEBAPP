<?php error_reporting(E_ALL); 
 
$query="SELECT * FROM events where EventCategory='workshop'"; 
 
$result=mysql_query($connection, $query); 
 
while($row=mysql_fetch_assoc($result)){
  echo "$row['evntName']";
  echo "$row['eventCategory']"; 
} ?>