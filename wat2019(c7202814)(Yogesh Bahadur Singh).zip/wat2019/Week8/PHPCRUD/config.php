<?php
$h="localhost";
$u="root";
$p="";
$d="wat";
$conn = mysqli_connect($h, $u, $p, $d) or die("Error to Connect DB");
?>