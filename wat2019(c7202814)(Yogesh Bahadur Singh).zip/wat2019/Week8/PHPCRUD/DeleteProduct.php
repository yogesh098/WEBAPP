<?php
include('config.php');
   if(isset($_GET['cid']))
   {
   	 $deleteID=$_GET['cid'];
   }
   $sql="DELETE FROM products WHERE ProductID=$deleteID";
   mysqli_query($conn, $sql);
   if (mysqli_affected_rows($conn) > 0) {
	header('Location: watWk8.php');
   } else {
	echo "Error in query: $query. " . mysqli_error($conn);
	exit ;
   }
   
?>