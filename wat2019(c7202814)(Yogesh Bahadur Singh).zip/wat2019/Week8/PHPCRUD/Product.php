<!DOCTYPE HTML>
<html>
    <title> Product</title>
    <body>
        <h1>Product </h1>
</body>        
</form>
    </html>
<?php
include 'connfig.php';
   if(isset($_GET['cid']))
   {
   	 $amendID=$_GET['cid'];
   	 $sql="SELECT * FROM products WHERE ProductID=$amendID";
        $qry=mysqli_query($conn, $sql);
   	 echo "<table border=0 cellpadding=6 cellspacing=10>";
   	 echo "<form method='POST' action='UpdateProduct.php'>";
   	 while($row=mysqli_fetch_array($qry))
   	 {
   	 	echo "<tr>
            <td><input type='hidden' name='productid' value=".$row['ProductID']."></td>
            </tr>
            <tr>
   	 	    <td>ProductName:</td>
            <td><input type='text' name='product' value=".$row['ProductName']."></td>
            </tr>
            <tr>
            <td>ProductPrice:</td>
            <td><input type='text' name='price' value=".$row['ProductPrice']."></td>
            </tr>
            <tr>
            <td>ProductImageName:</td>
            <td><input type='text' name='image' value=".$row['ProductImageName']."></td>
            </tr>
            ";
   	 }

echo "<tr><td></td><td>
    <input type='submit' name='Product' value='Amend'>
    <input type = 'reset'>
</td></tr>";
        echo "</form></table>";
    }
?>
