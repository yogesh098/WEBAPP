<!DOCTYPE html>
<html>
<head>
	<title>List All Customer</title>
	<style>
		table{
			border-collapse : collapse;
		}
		</style>
</head>
<body>
	<table border=1 cellpadding="5" cellspacing="5" width=100%>
		
			<thead>
				<tr>
				<th>ProductID</th>
				<th>ProductName</th>
				<th>Price</th>
				<th>Image</th>
				<th>Amend</th>
				<th>Delete</th>
				</tr>
			</thead>				
			<tbody>
				<?php
				//SQL Statement for Select all Customer
				$sql="SELECT * FROM products";
				//making Connnection
				include('config.php');

				//Making Query
				$qry=mysqli_query($connection, $sql);
     			//Printing data with loop
     			while($row=mysqli_fetch_assoc($qry))
     			{
     				echo "
				<tr>
				<th>".$row['ProductID']."</th>
				<th>".$row['ProductName']."</th>
				<th>".$row['ProductPrice']."</th>
				<th><img src=../images/".$row['ProductImageName']."></th>
				<th><a href=AmendProduct.php?cid=".$row['ProductID'].">Amend </a></th>
				<th><a href=DeleteProduct.php?cid=".$row['ProductID'].">Delete</a> </th>
			</tr>
			";
		}
		?>
			</tbody>
		
		
	</table>

</body>
</html>