<?php
include('connection.php');
if(isset($_POST['InsertProduct']))
{
	
		$product = $_POST['product'];
		$price = $_POST['price'];
		$image = $_POST['image'];
	if($product!=""&&$price!=""&&$image!=""){
		$sql="INSERT INTO products
		(
		ProductName,
		ProductPrice,
		ProductImageName
	   )
			  Values('$product','$price','$image')
			  ";	
	mysqli_query($connection, $sql);
	header('Location: watWk8.php');
	}
	else{
		echo "All fields required";
		exit;
	}	
}
?>