<?php
include 'connection.php';
if(isset($_POST['AmendProduct']))
{
	extract($_POST);

	$sql="UPDATE products SET 
    ProductName = '$product',
	ProductPrice = '$price',
	ProductImageName = '$image'
    where ProductID = $productid
	      ";
	$qry=mysqli_query($connection, $sql);
	if($qry)
	{
		header('Location: watWK8.php');
	}
	else {
		// print error message
		echo "Error in query: $query. " . mysqli_error($connection);
		exit ;
	   }
	   
}
