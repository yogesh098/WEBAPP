<!DOCTYPE html> 
<html lang="en">    
<head>       
	<title>Web Applications and Technologies</title>       
	<link type="text/css" rel="stylesheet" href="css/main.css" />    
</head>    
<body>       
	<header>          
		<h1>Yogesh Bahadur Singh C7202814</h1>        
	</header>              
	<section id="container">          
		<h1>Further Fundamentals of PHP</h1>

		<?php
		echo "<h2>Arrays</h2>";
		echo "<h4>Simple Arrays</h4>";
		echo"<br/>";
		?>
		 <h1>Further Fundamentals of PHP</h1>


		<?php
		echo("<h1>Arrays</h1>");
		echo("<h3>Sub-Arrays</h3>");
			$Product = array (
			'0' => 't-shirt', 
			'1' => 'cap', 
			'2' => 'mug', 
			);
		print_r ($Product);
		echo "<br>";
		
		$Product = array (
			'0' => 't-shirt', 
			'1' => 'cap', 
			'2' => 'mug',
			);
		$a2 = array('2' => 'orange');
		array_splice($Product,1,1,$a2);
		print_r($Product);
		echo "<br>";


		$Product = array (
			'1' => 't-shirt', 
			'2' => 'cap', 
			'3' => 'mug',
			);
		$a3 = array("4" => "skirt");
		array_splice($Product,1,1,$a2);
		print_r(array_merge($Product,$a3));
		print_r( "Items in my products array");
		echo "<br>";

		print_r( "Items in my products array<br/>");
		echo "The item at index[2] is: " . $Product[2]["0"] . $Product[2]["1"] . $Product[2]["2"];
		echo "<br/>";
		echo "The item at index[3] is: " . $a3[4]["0"] . $a3[4]["1"] . $a3[4]["2"] . $a3[4]["3"] . $a3[4]["4"];
		echo "<br/>";
		?>


		<?php
		echo "<h4>Associative Ararys</h4>";
		$Customer = array('CustID' => 12, 'CustName' => 'Sarah', 'CustAge' => 23, 'CustGender' => 'F');
		print_r($Customer);
		echo "<br/>";
		$b2 = array("CustEmail"=>"sarah@gmail.com");
		print_r(array_merge($Customer,$b2));
		echo "<br/>";
		echo "The item at index[CustName] is: ", $Customer["CustName"];
		echo "<br/>";
		echo "The item at index[CustEmail] is : ", $b2["CustEmail"];
		echo "<br/>";
		?>

		<?php
		echo "<h4>Multi-Dimensional Arrays</h4>";
		echo "This is my order:<br>";

		$stocks =array('id1' =>  
			               array('description' => 't-shirt','price'=>9.99,'stock'=>'100','colour1'=>'blue','colour2'=>'red','colour3'=>'green'),
	                  'id2' =>  
	                       array('description' => 'cap','price'=>4.99,'stock'=>'50','colour1'=>'blue','colour2'=>'black','colour3'=>'grey'),
	                  'id3' =>  
	                   	   array('description' => 'mug','price'=>6.99,'stock'=>'30','colour1'=>'yellow','colour2'=>'green','colour3'=>'pink'));
		echo $stocks['id1']['colour3'];
		echo $stocks['id1']['description'];
		echo "<br>";
		echo "Price:";
		echo $stocks['id1']['price'];
		echo "<br>";
		echo $stocks['id2']['colour3'];
		echo $stocks['id2']['description'];
		echo "<br>";
		echo "Price:";
		echo $stocks['id2']['price'];
		?>

		<?php
		echo "<h2>Loops</h2>";
		echo"<h2>While Loop</h2>";
		?>

		<?php
		$counter=1;
		  $shirt_price = 9.99;
        while ($counter < 11) {
        	
        	echo "" . $counter . " - ";
        	echo $total=$counter*$shirt_price;
        	echo "<br/>";
        	       	$counter++;
        	
        }
        	?>
        	<?php
 echo("<h2>Multi-Dimensional Arrays</h2>");
 $stock = array(
            "id1"=>array(
                    "description"=>"t-shirt",
                    "price"=>9.99,
                    "stock"=>100,
                    "colour"=>array(
                                    "blue",
                                    "green",
                                    "red"
                                    )
                        ),
             "id2"=>array(
                    "description"=>"cap",
                    "price"=>4.99,
                    "stock"=>50,
                    "colour"=>array(
                                    "blue",
                                    "black",
                                    "grey"
                                    )
                        ),
            "id3"=>array(
                    "description"=>"mug",
                    "price"=>6.99,
                    "stock"=>30,
                    "colour"=>array(
                                    "yellow",
                                    "green",
                                    "pink"
                                    )
                        )
                );
 print_r($stock);
 echo("<br/><br/>This is my order:<br/>");
print_r($stock["id1"]["colour"]["1"]." ".$stock["id1"]["description"]."<br/>Price: £".$stock["id1"]["price"]."<br/>");
print_r($stock["id2"]["colour"]["2"]." ".$stock["id2"]["description"]."<br/>Price: £".$stock["id2"]["price"]."<br/>");
echo("<h1>Loops</h1>");
echo("<h3>While Loop</h3>");
$counter = 1;
while($counter<6){
    echo 'Count : '.$counter.'<br />';
    $counter++;
}
$shirt_price = 9.99;
$counter = 1;
echo("<br/><table border=5 cellpadding=3 cellspacing=3 width=200>");
echo("<tr>");
echo("<th>Quantity</th>");
echo("<th>Price</th>");
while($counter<=10){
    $total = $counter * $shirt_price;
    echo("<tr>");
    echo("<td>".$counter."</td>");
    echo("<td>"."£".number_format($total)."</td>");
    $counter++;
}
echo("</table>");
echo("<h3>For Loops</h3>");
$names = array("a","b","c","d","e");
for($i=0;$i<5;$i++){
    echo $names[$i] .'<br />'; 
}
echo("<h3>Foreach Loops</h3>");
$names = array(
        array("a" => array("ID"=>"c7202825")),
        array("b" => array("ID"=>"c7202840")),
        array("c" => array("ID"=>"c7202850")),
        array("d" => array("ID"=>"c7202860")),
        array("e" => array("ID"=>"c7202670"))
);
foreach($names as $high){
    foreach($high as $key=>$great){
        echo "Name: $key";
        foreach($great as $green=>$value){
        echo " $green:$value<br/>";
        }
    }
}
$city=array('Peter'=>'LEEDS','Kat'=>'bradford','Laura'=>'wakeFIeld');
$location = [];
print_r($city);
echo '<br/>';
foreach($city as $name=>$value){
    $value = ucfirst(strtolower($value));
    $location[$name] = $value;
}
print_r($location);

echo"<h1>Some Useful Functions</h1><br/>";
$password = " password";
$password=trim($password);
$password = htmlentities($password);
echo"Password is $password <br/>";
if(isset($password)&&(empty($password)==false)){
    if((strlen($password)>=6 && strlen($password)<=8)){
        if(is_numeric($password)==false ){
        echo"Password is ok";
        }
        else{
            echo"Password cannot be a number";
        }
    }
    else{
        echo"Your password must be between 6 and 8 characters in length.";
    }
}
else{
    echo"Please enter a password.";
}
echo"<br/>";
$password=md5($password);

        	?>

	<footer>             
		<small> <a href="wat2019/watIndex.html">Home</a></small>       
	</footer>    
</body> 
</html