			 <?php 
			// include('nav/connection.php');
                $con=mysqli_connect('localhost','root','','mrshoes');
                $get_products="SELECT * FROM products limit 0,10";

                $run_products=mysqli_query($con,$get_products);

                while ($run_product=mysqli_fetch_assoc($run_products)) {
                  $up = $run_product['product_id']; 
                	echo"<div class='col-md-3'>
                  <div class='card'>";
                  if($run_product['product_keyword']=="mens"){
                 echo"<img src='../admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                           if(isset($_SESSION['name'])){  
                           	echo"
                                 <a href='nav/getfavlist.php?product_id=$id' class='btn btn-success'><i class='fa fa-favourite-plus' aria-hidden='true' name='add_to_favourite'></i>Add To favourite</a>
                                ";
                            }
                 echo"</div></div>";
            
          }
        
         ?>
