<?php 

$con=mysqli_connect('localhost','root','','mrshoes');

$get_products="SELECT * FROM products limit 10,8";

$run_products=mysqli_query($con,$get_products);

  while ($run_product=mysqli_fetch_array($run_products)) {
    $id=$run_product['product_id'];
    echo"<div class='col-md-3'>
          <div class='card'>";
              if($run_product['product_keyword']=="womens"){
                echo"<img src='../admin/images/womens/".$run_product['product_img1']."' class='card-img-top'>";
                echo"
                  
                    <h5>".$run_product['product_title']."</h5></a>";

                echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";

                echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
              if(isset($_SESSION['name'])){  
                echo"<button type='button' class='btn btn-success'>
                        <a href='../nav/getfavlist.php?product_id=$id'>
                        <i class='fa fa-cart-plus' aria-hidden='true'></i>Add To favourite</a>
                     </button>
                     ";
                            }
                 echo"</div>
                       </div>
                        ";
            
          }
        
?>