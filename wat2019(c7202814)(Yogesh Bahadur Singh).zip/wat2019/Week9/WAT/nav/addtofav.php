<?php

$product_id=$_GET["product_id"];
setcookie("myfav[$product_id]", $product_id, time()+(60*60*24*30), "/");
echo "Cookie added";

echo "<a href='getfavlist.php'?product_id=$product_id>GET LIST of FAV</a>";
//header('location: getfavlist.php')

?>