<?php
include('includes/connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script>tinymce.init({selector:'textarea'});</script>
	<title>admin</title>
</head>
<body>
	<div class="row"><!--row start-->
		<div class="col-lg-12">
			<div class="breadcrumb">
				<li class="active">
					<l class="fa fa-dashboard"></l>
					Dashboard
				</li>
				
			</div>
			
		</div>
		
	</div><!--row end-->

	<h1>ADMIN CONTROL PANEL</h1>
		<div class="container">
</div>
		
	</form>
    </div>
    </div>



  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">ADMIN PANEL </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark active" >Dashboard</a>
        <a href="products.php" class="list-group-item list-group-item-action bg-dark">Products</a>
        <a href="#" class="list-group-item list-group-item-action bg-dark">Profile</a>
        <a href="../index.php" class="list-group-item list-group-item-action bg-light">SHOP</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    

      <div class="container-fluid">
        <h1 class="mt-4">Simple Sidebar</h1>
        <p>The starting state of the menu will appear collapsed on smaller screens, and will appear non-collapsed on larger screens. When toggled using the button below, the menu will change.</p>
        <p>Make sure to keep all page content within the <code>#page-content-wrapper</code>. The top navbar is optional, and just for demonstration. Just create an element with the <code>#menu-toggle</code> ID which will toggle the menu when clicked.</p>
      </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->

</body>

</html>
