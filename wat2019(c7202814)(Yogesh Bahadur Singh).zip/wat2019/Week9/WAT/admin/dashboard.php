
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/regcss.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="../js/bootstrap.js"></script>

  <title>login form</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
	<style>
	.header {
		background: #003366;
	}
	button[name=register_btn] {
		background: #003366;
	}
	</style>
	<script>tinymce.init({selector:'textarea'});</script>

</head>
<body>
	<div class="container-fluid bg-dark header-top">
  <div class="container">
    <div class="row text-light pt-2 pb-2">

      <div class="col-md-3">
         <img href="www.facebook.com" src="images/facebook.png" width="40" height="40" alt="Facebook-logo">
         <img src="images/instagram.png" width="30" height="30" alt="Instagram-logo">
         <img src="images/twitter.png" width="40" height="40" alt="Instagram-logo">
      </div>
      <div class="col-md-4">
        
      </div>
    
      <div class="col-md-2"><a href="customer/my_account.php">
              <i class="fa fa-user-o" aria-hidden="true"></i>
        ADMIN</a>
      </div>

      <div class="col-md-2"><a href="nav/cart.php">
        <i class="fa fa-cart-plus" aria-hidden="true"></i>
       ADMIN</a>
      </div>

      <div class="col-md-1">
      <a href='nav/login.php'> 
       <button class='btn btn-outline-success my-2 my-sm-0' type='submit'>LOGIN</button></a>      
      </div>

      </div>
    </div>
</div>




	<div class="header">
		<h2>Admin - Home Page</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<div class="profile_info">
			<img src="../images/admin_profile.png"  >

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="home.php?logout='1'" style="color: red;">logout</a>
                       &nbsp; <a href="create_user.php"> + add user</a>
					</small>

				<?php endif ?>
			</div>
		</div>
	</div>



	<div class="row"><!--row start-->
		<div class="col-lg-12">
			<div class="breadcrumb">
				<li class="active">
					<l class="fa fa-dashboard"></l>
					Dashboard / Insert Product
				</li>
				
			</div>
			
		</div>
		
	</div><!--row end-->
	<div class="container">

	<div class="row">
		<div class="col-md-3">
			
		</div>
		<div class="col-lg-6">
			<div class="panael panel-deafault">
				<div class="panel-heading"><!--panel heading start-->
					<h3><i class="fa a-money fa-w"></i>Insert Product</h3>
				</div><!--panel heading end-->
				<div class="panel-body">
					<form class="form-horizontal" method="post" enctype="multiple/form-data">

						<div class="form-group">
							<label class="col-md-3" control-label>Product Title</label>
							<input type="text" name="product_title" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Image 1</label>
							<input type="file" name="product_img1" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Image 2</label>
							<input type="file" name="product_img2" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Image 3</label>
							<input type="file" name="product_img3" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Image 4</label>
							<input type="file" name="product_img4" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Image 5</label>
							<input type="file" name="product_img5" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Price</label>
							<input type="text" name="product_price" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Description</label>
							<textarea name="product_desc" class="form-control" rows="6" cols=""></textarea>
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Keyword</label>
							<input type="text" name="product_keyword" class="form-control" required="">
						</div>

						<div class="form-group">
							<input type="submit" name="submit" value="Insert Product" class="btn btn-primary form-control">
						</div>
						
					</form>
				</div>
			</div>
			<div class="col-lg-3">
				
			</div>
		</div>	
	</div>
</div>

<?php
if (isset($_POST['submit'])) {
	$product_title=$_POST['product_title'];

	$product_img1=$FILES['product_img1']['name'];
	$product_img2=$FILES['product_img2']['name'];
	$product_img3=$FILES['product_img3']['name'];
	$product_img4=$FILES['product_img4']['name'];
	$product_img5=$FILES['product_img5']['name'];

	$temp_name1=$FILES['product_img1']['tmp_name'];
	$temp_name2=$FILES['product_img2']['tmp_name'];
	$temp_name3=$FILES['product_img3']['tmp_name'];
	$temp_name4=$FILES['product_img4']['tmp_name'];
	$temp_name5=$FILES['product_img5']['tmp_name'];

	move_uploaded_file($temp_name1,"product_images/$product_img1");
	move_uploaded_file($temp_name2,"product_images/$product_img2");
	move_uploaded_file($temp_name3,"product_images/$product_img3");
	move_uploaded_file($temp_name4,"product_images/$product_img4");
	move_uploaded_file($temp_name5,"product_images/$product_img5");

	$product_price=$_POST['product_price'];
	$product_desc=$_POST['product_desc'];
	$product_keyword=$_POST['product_keyword'];

	$insert_product="insert into products(date,product_title,product_img1,product_img2,product_img3,product_img4,product_img5,product_price,product_desc,product_keyword) value(NOW(),'$product_title','$product_img1','$product_img2','$product_img3','$product_img4','$product_img5','$product_price','$product_desc','$product_keyword')";
	
	$run_product=mysqli_query($con,$insert_product);
	if ($run_product) {
		echo "<script>alert('Product Inserted Successfully')</script>";
		echo "<script>window.open('insert_product.php')</script>";
	}
}
?>

</body>
</html>