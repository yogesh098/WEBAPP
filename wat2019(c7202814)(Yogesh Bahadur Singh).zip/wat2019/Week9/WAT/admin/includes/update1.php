<?php
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Activity | Visit Nepal 2020</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../admin/includes/styles.css" />
</head>
<body>

<div class="container">
<div id='addProd'><h4>Update Activity</h4>
<form action='update1.php' method='POST' enctype='multipart/form-data'>

<table id="addTable" cellspacing="10">
<input type="hidden" name="product_id" value="<?php echo $_GET['product_id']; ?>"/>
   
    <tr>
        <td align="left"><b>Product Image</b></td>
         <td><input type="file" name="product_img1" value="<?php echo $_GET['product_img1'];?>" accept=".jpg, .jpeg, .png" required/></td>
    </tr>
    <tr>
        <td align="left"><b>Product Title:</b></td>
        <td><input type="text" name="product_title" placeholder="Product Title" value="<?php echo $_GET['product_title']; ?>"required/></td>
    </tr>
    <tr>
        <td align="left"><b>Product List Price: $</b></td>
        <td><input type="text" name="product_list_price" value="<?php echo $_GET['product_list_price']; ?>" required/></td>
       
    </tr>
    <tr>
        <td align="left"><b>Product Price: $</b></td>
        <td><input type="text" name="product_price" value="<?php echo $_GET['product_price']; ?>" required/></td>
    </tr>
    <tr>
        <td align="left"><b>Product Description:</b></td>
        <td><textarea name="product_desc" cols="40" rows="10" value="<?php echo $_GET['product_desc']; ?>"required></textarea></td>
    </tr>
    <tr>
        <td align="left"><b>Product keyword</b></td>
        <td><input name="product_keyword" cols="40" rows="10" value="<?php echo $_GET['product_keyword']; ?>"required></input></td>
    </tr>
    <tr>
        <td align="left"><b>Product Brand</b></td>
        <td><input name="product_brand" cols="40" rows="10" value="<?php echo $_GET['product_brand']; ?>"required></input></td>
    </tr>
    <tr align="center">
    <td colspan="2"><input type="submit" name="update" value="submit"/></td>
    </tr> 

    </table>
</form>
</div>


</div>
</div>    
</body>
</html>




<?php
if(isset($_POST['update'])){
$pro_id = $_POST['product_id'];

$pro_img = $_POST['product_img1'];
$file_size =$_FILES['product_img1']['size'];
$file_tmp =$_FILES['product_img1']['tmp_name'];
$file_type=$_FILES['product_img1']['type'];

move_uploaded_file($file_tmp,"product_images/".$pro_img);

$pro_title = $_POST['product_title'];
$pro_list_price = $_POST['product_list_price'];
$pro_price = $_POST['product_price'];
$pro_desc = $_POST['product_desc'];
$pro_keyword = $_POST['product_keyword'];
$pro_brand = $_POST['product_brand'];

//taking the text input from the fields
/*$pro_id=$_POST['product_id'];
$pro_img = $_FILES['product_img1']['name'];//taking the image input from the fields

      $file_size =$_FILES['product_img1']['size'];
      $file_tmp =$_FILES['product_img1']['tmp_name'];
      $file_type=$_FILES['product_img1']['type'];
      // $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      //    $extensions= array("jpeg","jpg","png");

      move_uploaded_file($file_tmp,"product_images/".$pro_img);
$pro_title=$row_pro['product_title'];
$pro_list_price=$row_pro['product_list_price'];
$pro_price=$row_pro['product_price'];
$pro_desc=$row_pro['product_desc'];
$pro_keyword=$row_pro['product_keyword'];
$pro_brand=$row_pro['product_brand'];       
*/

//adding the data into the database
$update_product="update products set product_img1='$pro_img', product_title='$pro_title', product_list_price='$pro_list_price', product_price='$pro_price', product_desc='$pro_desc',product_keyword='$pro_keyword',product_brand='$pro_brand'  where product_id='$pro_id'";

$updateprod=mysqli_query($con, $update_product);

if($updateprod){
	echo "<script>alert('Activity updated !')</script>";
	echo"<script> window.location='../products.php'; </script>";
}	
	
}
?>
