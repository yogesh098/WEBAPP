<?php
include('connection.php');


$get_products="SELECT * FROM products";

$run_products = mysqli_query($con,$get_products);

?>
<table class='table table-hover table-striped table-bordered'>

    <tr>
      <th scope='col'>Product Id</th>
      <th scope='col'>Date</th>
      <th scope='col'>Product Image Name</th>
      <th scope='col'>Product Title</th>
      <th scope='col'>Product List Price</th>
      <th scope='col'>Product Price</th>
      <th scope='col'>Product Description</th>
      <th scope='col'>Product Keyword</th>
      <th scope='col'>Product Brand</th>
      <th scope="col">Product Update</th>
      <th scope="col">Product delete</th>
    </tr>


	
  <?php
  while ($run_product = mysqli_fetch_assoc($run_products)):
    $up = $run_product['product_id'];
    $im = $run_product['product_img1'];
    $ti = $run_product['product_title'];
    $li = $run_product['product_list_price'];
    $pr = $run_product['product_price'];
    $de = $run_product['product_desc'];
    $ke = $run_product['product_keyword'];
    $br = $run_product['product_brand'];
  	?>
  	
    <tr>
      <td><?php echo $run_product['product_id'] ?></td>
      <td><?php echo $run_product['date'] ?></td>
      <td><img src="product_images/<?php echo $run_product['product_img1'] ?>" style="width:100px; height:1oopx;"></a></td>
      <td><?php echo $run_product['product_title'] ?></td>
      <td><?php echo $run_product['product_list_price'] ?></td>
      <td><?php echo $run_product['product_price'] ?></td>
      <td><?php echo $run_product['product_desc'] ?></td>
      <td><?php echo $run_product['product_keyword'] ?></td>
      <td><?php echo $run_product['product_brand'] ?></td>
      <td><?php echo"<a href='includes/update1.php?product_id=$up&product_img1=$im&product_title=$ti&product_list_price=$li&product_price=$pr&product_desc=$de&product_keyword=$ke&product_brand=$br'><i class='fa fa-update'>Update</i></a></td>";?>
      <td><?php echo"<a href='includes/delete.php?product_id=$up'><i class='fa fa-delete'>Delete</i></a></td>";?>
    </tr>
  <?php endwhile; ?>

</table>