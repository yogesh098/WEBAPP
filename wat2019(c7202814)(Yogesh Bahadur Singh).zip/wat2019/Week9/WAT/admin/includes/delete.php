<?php
include 'connection.php';
if(isset($_GET['product_id'])){
    $pro_id=$_GET['product_id'];

    $delete = mysqli_query($con, "DELETE FROM products WHERE product_id = $pro_id");
    if($delete){
    
        echo "<script>alert('Activity Successfully Removed')</script>";
        echo"<script> window.location='../products.php'; </script>";
       
    }
}
else {
    echo "Failed to delete the products";
    echo"<script> window.location='../products.php'; </script>";

    
}
?>