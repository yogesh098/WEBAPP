<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="../../js/jquery.min.js"></script>
  <script type="text/javascript" src="../../js/proper.min.js"></script>
  <script type="text/javascript" src="../../js/bootstrap.min.js"></script>
  <title>Mr.SHOES</title>
</head>
<body>
<div class="container-fluid bg-dark header-top">
  <div class="container">
    <div class="row text-light pt-2 pb-2">

      <div class="col-md-3">
         <img href="www.facebook.com" src="../../images/facebook.png" width="40" height="40" alt="Facebook-logo">
         <img src="../../images/instagram.png" width="30" height="30" alt="Instagram-logo">
         <img src="../../images/twitter.png" width="30" height="30" alt="Instagram-logo">
      </div>
      <div class="col-md-3">
        
      </div>
    
      <div class="col-md-2">
        <i class="fa fa-user-o" aria-hidden="true"></i>
        ACCOUNT
      </div>

      <div class="col-md-2">
        <i class="fa fa-cart-plus" aria-hidden="true"></i>
        My Cart - $0.00
      </div>
      <div class="col-md-2">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">LOGIN</button>
      </div>
      
      </div>
    </div>
</div>

<div class="container-fluid bg-black">
  <nav class="container navbar navbar-expand-lg navbar-dark bg-black">
  <a class="navbar-brand" href="../../index.php">
    <img src="../../images/mr.png" width="40" height="40" alt="Shoes-logo">MR.SHOES</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="col-md-4 offset-md-3">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="../../index.php">HOME <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">NEW</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          CATEGORY
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="kids.php">KIDS</a>
          <a class="dropdown-item" href="adult.php">ADULT</a>
          <a class="dropdown-item" href="womens.php">WOMENS</a>
          <a class="dropdown-item" href="men.php">MENS</a>
          <div class="dropdown-divider"></div>

          <a class="dropdown-item" href="#">Something else</a></a>
          <a class="dropdown-item" href="#">Something else</a></a>

        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">ABOUT</a>
      </li>
    </ul>
  </div>
</div>
<div class="col-md-6">
      <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-1" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
    </div>
</nav>
</div>
  
    <div class="container">
  <div class="row">
    <div class="col-md-6">
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active"> 
            <img class="d-block w-100" src="../../images/mens/AirJordan/1.jpg" alt="First slide"> </div>
          <div class="carousel-item"> <img class="d-block w-100" src="../../images/mens/AirJordan/2.jpg" alt="Second slide"> </div>
          <div class="carousel-item"> <img class="d-block w-100" src="../../images/mens/AirJordan/3.jpg" alt="Second slide"> </div>
          <div class="carousel-item"> <img class="d-block w-100" src="../../images/mens/AirJordan/4.jpg" alt="Second slide"> </div>
          <div class="carousel-item"> <img class="d-block w-100" src="../../images/mens/AirJordan/5.jpg" alt="Second slide"> </div>
          <div class="carousel-item"> <img class="d-block w-100" src="../../images/mens/AirJordan/6.jpg" alt="Second slide"> </div>
        </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> 
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <h2>Air Jordan 1 High Zoom Fearless</h2>
      </div>
      <div class="row">
        <h1><i class="fa fa-dollar" aria-hidden="true"></i> 120</h1>
        &nbsp; &nbsp;
        <h3><del>160</del></h3>
        &nbsp; &nbsp;
        <h2 class="text-success">30% off</h2>
      </div>
      <div class="row">
        <h3 class="text-warning"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-half-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></h3>
        &nbsp; &nbsp;
        <h5>1200 star rating  and 250 reviews</h5>
        <p>Air Jordan 1 High Zoom Fearless = $160<br>
THE ICONIC 1.<br>

Familiar but always fresh, the iconic Air Jordan 1 is remastered for today's sneakerhead culture. This Retro High OG version goes all in with full-grain leather, comfortable cushioning and classic design details.<br>

Air Inside<br>
The Air-Sole unit in the heel provides the same lightweight cushioning that MJ enjoyed back in his playing days.<br>

Leather Luxe<br>
Full-grain leather provides lightweight support and OG basketball sneaker style.<br>

Classic Cupsole<br>
Why mess with greatness? Stable and supportive, the shoe's cupsole has the same profile and thick stitch detailing as the original.<br>

Product Details<br>
Rubber tread with deep flex grooves<br>
Perforated toe box<br>
Shown: Black/White/Gym Red<br>
Style: 555088-062<br>
</p>
      </div>
     <div class="row">
        <p><i class="text-success fa fa-check-square-o" aria-hidden="true"></i> <strong>Bank Offer</strong> 20% Instant Discount on SBI Credit Cards</p>
        <p><i class="text-success fa fa-check-square-o" aria-hidden="true"></i> <strong>Bank Offer</strong> 5% Unlimited Cashback on Flipkart Axis Bank Credit Card </p>
        <p><i class="text-success fa fa-check-square-o" aria-hidden="true"></i> <strong>Bank Offer</strong> Extra 5% off* with Axis Bank Buzz Credit Card</p>
        <p><i class="text-success fa fa-check-square-o" aria-hidden="true"></i> <strong>Bank Offer</strong>20% Instant Discount on pay with <i class="fa fa-google-wallet" aria-hidden="true"></i> google wallet </p>
      </div>
      <div class="row mt-4">
        <h3 class="text-info"><i class="fa fa-map-marker" aria-hidden="true"></i></h3>
        <p style="font-size: 20px"> &nbsp; Delivery by23 Jul, Tuesday | &nbsp; <span class="text-success">FREE</span> </p>
      </div>
      <div class="row mt-4">
        <h4>Size: &nbsp; &nbsp;</h4>
        <div class="dropdown show"> <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Select sizes </a>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink"> <a class="dropdown-item" href="#">small</a> <a class="dropdown-item" href="#">meduam </a> <a class="dropdown-item" href="#">large</a> </div>
        </div>
      </div>
      <div class="row mt-4">
        <h4>Colors: &nbsp; &nbsp; </h4>
        
        <a class="btn btn-primary text-light">Sky Blue</a> &nbsp; <a class="btn btn-danger text-light"> red</a>&nbsp; <a class="btn btn-info text-light"> blue </a> &nbsp; <a class="btn btn-warning text-light"> yellow</a> &nbsp; <a class="btn btn-success text-light"> green</a>
      </div>
      
      <div class="row mt-4">
        <h4>Seller: &nbsp; &nbsp;</h4>
        <p style="font-size: 18px">G.M Garments </p>
      </div>
      
    </div>
  </div>
</div>
  
  </body>
</html>