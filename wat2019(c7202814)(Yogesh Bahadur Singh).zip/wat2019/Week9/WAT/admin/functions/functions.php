<div class="container">
     <div class='row'>
			  <?php
			  $con=mysqli_connect('localhost','root','','mrshoes');
			  function getPro(){

			  global $con;

			  $get_products="select * from products order by product_id DESC limit 4";

			  $run_products=mysqli_query($con,$get_products);

			  while ($run_product=mysqli_fetch_array($run_products)) 
			  	{  
			  		?>
                    <div class='col-md-3'>
					    <div class='card'><a href='#'><img src='<?php $run_products['product_img1']; ?>'></a>
                        </div>
                        <div class='card-body'>
                            <a href='details/details1.php?product_id=$product_id'>
                        <h5><?php $run_product['product_title']; ?></h5></a>


                            <p class='price'>Our Price:<?php $run_product['product_price'];?></p>	<a href='nav/details/details1.php?product_id=$product_id' class="btn btn-success">DETAILS</a>
                            </button>
                                <a href='nav/details/details1.php?product_id=$product_id' class="btn btn-success">Add To Cart</a>		   
                        </div>
			<?php
			 } 
			}
			?>
		</div>
	</div>

</body>
</html>     



<!--	 <div class='card'>
                        <a href='nav/details/details1.php'>
                            <img  src="$run_products['product_title'];" class='card-img-top'></a>
                </div>
                        <div class='card-body'>
                            <a href='nav/details/details1.php'>
                        <h5>Air Jordan 1 High Zoom Fearless</h5></a>
                            <p class='list-price text-danger'>List Price:<s>$160.79</s></p>
                            <p class='price'>Our Price: $120</p>
                        <button  type='button' class='btn btn-success'>
                        	<a href='nav/details/details1.php'>DETAILS</a>
                        </button>
                        <button type='button' class='btn btn-success'>
                            <a href='nav/details/details1.php'>Add To Cart</a>
                        </button>
                    </div>
               </div>
            </div>
        </div>  
		";
	}
}
?>
