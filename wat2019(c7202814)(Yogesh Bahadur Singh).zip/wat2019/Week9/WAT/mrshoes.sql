-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2020 at 12:57 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mrshoes`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_img1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `product_list_price` int(255) NOT NULL,
  `product_price` int(8) NOT NULL,
  `product_desc` longtext COLLATE utf8_unicode_ci NOT NULL,
  `product_keyword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_brand` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `date`, `product_img1`, `product_title`, `product_list_price`, `product_price`, `product_desc`, `product_keyword`, `product_brand`) VALUES
(15, '2020-01-04 05:49:52', '1a.jpg', 'AirJordan', 150, 120, 'quiet nice one', 'mens', 'Nike_mens'),
(17, '2020-01-07 10:29:58', 'jordan-mars-270-mens-shoe-kFshZR1.jpg', 'JordanMars', 130, 120, 'Grab it.', 'mens', 'Nike_mens'),
(18, '2020-01-04 05:50:01', '1b.jpg', 'Bowfin', 120, 120, 'nice one', 'mens', 'Nike_mens'),
(25, '2020-01-04 19:17:24', 'air-max-270-react-winter-mens-shoe-tCkNHl2.jpg', 'Nike Air Max 270 winter mens shoes', 160, 120, 'Meet the softest, smoothest and most resilient Nike Air Max 270 React Winter.', 'mens', 'Nike_mens'),
(26, '2020-01-04 19:06:07', 'vapormax.jpg', 'Nike Air VaporMax Flyknit 3', 160, 120, 'Nike Air VaporMax Flyknit 3', 'mens', 'Nike_mens'),
(27, '2020-01-04 19:07:13', 'joyride.jpg', 'Nike Joyride Dual Run', 160, 120, 'Nike Joyride Dual Run fine project made for jogging.', 'mens', 'Nike_mens'),
(28, '2020-01-04 19:09:25', 'zoom-pegasus-turbo-shield-mens-running-shoe-NMvh16.jpg', 'Nike Zoom Pegasus Turbo Shield', 210, 160, 'The Nike Zoom Pegasus Turbo Shield delivers your favorite lightweight running shoe in a smart, weatherized design, so you can continue training in confidence despite those dark and rainy months.\r\n', 'mens', 'Nike_mens'),
(29, '2020-01-04 19:26:04', 'air-max-270-react-mens-shoe-bZ8t5l0.jpg', 'Nike Air Max 270 React', 160, 120, 'The bold silhouette of Nike Air lifts the Nike Air Max 270 React to new heights, while the Nike React foam midsole delivers exceptional cushioning.', 'mens', 'Nike_mens'),
(30, '2020-01-04 19:26:29', 'air-force-270-utility-realtree-mens-shoe-nmr0Ld0.jpg', 'Air Force 270 Utility Realtree Mens Shoe', 120, 91, 'Make your mark on the street in the audacious Nike Air Force 270 Utility RealtreeÂ®. Crafted to conquer seasonal villains like the cold and rain, it features water- and abrasion-resistant materials on its mid-height upper.', 'mens', 'Nike_mens'),
(31, '2020-01-04 19:26:33', 'air-max.jpg', 'Nike Air Max Womens Shoes', 210, 120, 'Make your mark on the street in the audacious Nike Air Force 270 Utility RealtreeÂ®. Crafted to conquer seasonal villains like the cold and rain, it features water- and abrasion-resistant materials on its mid-height upper.', 'womens', 'Nike_womens'),
(32, '2020-01-04 19:25:13', 'air-max2.jpg', 'Nike Air Max Womens Shoes', 160, 156, 'Make your mark on the street in the audacious Nike Air Force 270 Utility RealtreeÂ®. Crafted to conquer seasonal villains like the cold and rain, it features water- and abrasion-resistant materials on its mid-height upper.', 'womens', 'Nike_womens'),
(33, '2020-01-04 19:28:12', 'zoom-x.jpg', 'Nike Zoom Women Shoes', 210, 156, 'Make your mark on the street in the audacious Nike Air Force 270 Utility RealtreeÂ®. Crafted to conquer seasonal villains like the cold and rain, it features water- and abrasion-resistant materials on its mid-height upper.', 'womens', 'Nike_womens'),
(34, '2020-01-04 19:29:09', 'air-zoom.jpg', 'Nike Air Zoom Womens Shoes', 160, 156, 'Make your mark on the street in the audacious Nike Air Force 270 Utility RealtreeÂ®. Crafted to conquer seasonal villains like the cold and rain, it features water- and abrasion-resistant materials on its mid-height upper.', 'womens', 'Nike_womens'),
(35, '2020-01-04 20:05:24', 'air-max-ff-720-womens-shoe-cmm0bQ.jpg', 'Air Max FF 720 Womens Shoe', 160, 120, 'air-max-ff-720-womens-shoe made for those who want some thing new.', 'womens', 'Nike_womens'),
(36, '2020-01-04 20:03:49', 'air-force-1-sp-womens-shoe-CsrVcC.jpg', 'Air Force 1 SP Womens Shoe', 160, 91, 'air force 1 sp womens shoe are made.', 'womens', 'Nike_womens'),
(37, '2020-01-04 20:05:04', 'air-force-1-shell-womens-shoe-5mS54B.jpg', 'Air Force 1 Shell Womens Shoe', 160, 156, 'air-force-1-shell-womens-shoe-5mS54B', 'womens', 'Nike_womens'),
(38, '2020-01-04 20:06:26', 'air-max-tailwind-iv-womens-shoe-Gh2d5w.jpg', 'air-max-tailwind-iv-womens-shoe-Gh2d5w.jpg', 160, 120, 'air-max-tailwind-iv-womens-shoe-Gh2d5w', 'womens', 'Nike_womens'),
(39, '2020-01-04 20:09:34', 'shoes_ia98593.jpg', 'Nike Air Kids Shoes', 160, 120, 'This shoes is made for those who loves to have it.', 'kids', 'Nike_kids'),
(40, '2020-01-04 20:11:02', 'shoes_ia98595.jpg', 'Nike Air Dob Kids Shoes', 160, 120, 'This shoes is made for actual fun. Grab it fast.', 'kids', 'Nike_kids'),
(41, '2020-01-04 20:12:35', 'shoes_ia98692.jpg', 'Nike Air Runner Kids Shoes', 210, 156, 'Nike Air Runner Shoes are made for those who love to play with design.', 'kids', 'Nike_kids'),
(42, '2020-01-04 20:14:47', 'shoes_ib98613.jpg', 'Nike Air Max Kids Shoes', 210, 160, 'Nike Air Max Kids Shoes made for all type of seasons and can handle different situations.', 'kids', 'Nike_kids'),
(43, '2020-01-04 20:16:00', 'shoes_ib98697.jpg', 'Nike Air Buffer Kids Shoes', 210, 156, 'Nike Air Buffer Kids Shoes made for fun.', 'kids', 'Nike_kids'),
(44, '2020-01-04 20:17:46', 'shoes_id98248.jpg', 'Nike Air Max 270 Kids Shoes', 160, 120, 'Nike Air Max 270 Kids Shoes are made up of different types of materials to give your foot comfort.', 'kids', 'Nike_kids'),
(45, '2020-01-04 20:19:43', 'shoes_id98695.jpg', 'Nike DC Kids Shoes', 160, 120, 'Nike DC Kids Shoes made for those who love wearing different patterns.', 'kids', 'Nike_kids'),
(46, '2020-01-04 20:20:29', 'shoes_ie75840.jpg', 'Nike Kids Shoes', 160, 120, 'Grab it. Its all yours.', 'kids', 'Nike_kids'),
(47, '2020-01-06 05:13:26', '', 'sLKIOHugzk', 0, 0, '.;OJSPGUODACXZLKNM', 'AWSDCA', 'WAFS'),
(48, '2020-01-06 05:15:30', 'login.jpg', 'AirJordan', 10, 10, 'jihwius pohwhd wsgbx ', 'womens', 'Nike_womens');

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `id` int(255) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(255) NOT NULL,
  `role` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`id`, `name`, `email`, `password`, `gender`, `age`, `role`) VALUES
(2, 'user', 'user@gmail.com', 'user@1', 'female', 0, 2),
(4, 'admin', 'admin@gmail.com', 'admin@1', 'male', 0, 1),
(5, 'yogesh', 'yogesh@gmail.com', 'user@1', 'male', 0, 2),
(16, 'alo', 'alo@gmail.com', 'alo', 'male', 19, 2),
(17, 'aa', 'aa@gmail.com', 'a', 'male', 19, 2),
(18, 'aa', 'aa@gmail.com', 'a', 'male', 19, 2),
(19, 'a', 'a@gmail.com', 'a', 'male', 18, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
