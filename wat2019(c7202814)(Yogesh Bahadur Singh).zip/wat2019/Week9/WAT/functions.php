			 <?php 
			// include('nav/connection.php');
                $con=mysqli_connect('localhost','root','','mrshoes');
                $get_products="SELECT * FROM products limit 4";

                $run_products=mysqli_query($con,$get_products);

                while ($run_product=mysqli_fetch_assoc($run_products)) {
                  $product_id = $run_product['product_id'];
                	echo"<div class='col-md-3'><div class='card'>";
                  if($run_product['product_title']=="AirMax"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo" <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                   if($run_product['product_title']=="AirJordan"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";   
                  }
                  if($run_product['product_title']=="JordanMars"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";   
                  }
                  if($run_product['product_title']=="Bowfin"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";   
                  }
                  if($run_product['product_title']=="Nike Air Max 270 winter mens shoes"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";   
                  }
                           if(isset($_SESSION['name'])){  
                           	echo"<button type='button' class='btn btn-success'>
                                 <a href='nav/addtofav.php?product_id=$product_id'><i class='fa fa-cart-plus' aria-hidden='true'></i>Add To fav</a>
                                 </button>";
                            }
                 echo"</div></div>";
            
          }
        
         ?>
			     



<!--	 <div class='card'>
                        <a href='nav/details/details1.php'>
                            <img  src="$run_products['product_title'];" class='card-img-top'></a>
                </div>
                        <div class='card-body'>
                            <a href='nav/details/details1.php'>
                        <h5>Air Jordan 1 High Zoom Fearless</h5></a>
                            <p class='list-price text-danger'>List Price:<s>$160.79</s></p>
                            <p class='price'>Our Price: $120</p>
                        <button  type='button' class='btn btn-success'>
                        	<a href='nav/details/details1.php'>DETAILS</a>
                        </button>
                        <button type='button' class='btn btn-success'>
                            <a href='nav/details/details1.php'>Add To Cart</a>
                        </button>
                    </div>
               </div>
            </div>
        </div>  
		";
	}
}
?>
