<?php
include('header.php');
?>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">

      <img class="d-block w-100" src="admin/images/slider1a.jpg" alt="First slide">
      <div class="carousel-caption ">
    <h1>30% OFF DURING CHRISTMASS</h1>
    <p>Shop it, Grab it, make it yours</p>
    <a href="nav/mens.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="admin/images/slider2a.jpg" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
    <h1 >60% OFF IN CHRISTMASS</h1>
    <p>PLACE LIKE HEAVEN</p>
    <a href="nav/men.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="admin/images/slider3a.jpg" alt="Third slide">
      <div class="carousel-caption d-none d-md-block">
    <h5>I love SUNRISE.</h5>
    <p>PLACE LIKE HEAVEN</p>
    <a href="nav/men.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="admin/images/slider4a.jpg" alt="Fourth slide">
      <div class="carousel-caption d-none d-md-block">
    <h5>I love SUNRISE.</h5>
    <p>PLACE LIKE HEAVEN</p>
    <a href="nav/men.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="admin/images/slider5a.jpg" alt="Fifth slide">
      <div class="carousel-caption d-none d-md-block">
    <h5>I love SUNRISE.</h5>
    <p>PLACE LIKE HEAVEN</p>
    <a href="nav/men.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="admin/images/ba.bmp" alt="Sixth slide">
      <div class="carousel-caption d-none d-md-block">
    <h5>I love SUNRISE.</h5>
    <p>PLACE LIKE HEAVEN</p>
    <a href="nav/men.php">
    <button class="btn btn-info btn-lg">Shop Now</button></a>
  </div>
    </div>

  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>


<div class="container-fluid offer pt-3 pb-3 bg-orange d-none d-md-block">

    <div class="row">
      <div class="col-md-4 m-right">
        <h4>FREE SHIPPING</h4>
        <p>on order  ober $899</p>
      </div>
      <div class="col-md-4 m-right">
        <h4>CALL US ANYTIME(24 hr)</h4>
        <p>+977 9813284718</p>
      </div>
      <div class="col-md-4">
        <h4>OUR LOCATION</h4>
        <p>Maitidevi, Kathmandu</p>
      </div>
    </div>
</div>


<div class="container-fluid bg-light-gray">

  <div class="container-fluid pt-5">
   <div class="row">
      <h3>FEATURE MEN's WEAR</h3>
    </div>
    <div class="row">
      <div class="underline1"></div>
    </div>
</div>
  <br>
<div class="container">
  <div class="row">
    <?php
    include('functions.php');
    ?>
  </div>
</div><!--container end-->


<div class="container pt-5">
   <div class="row">
      <h3>Featured Womens Shoes</h3>
    </div>
    <div class="row">
      <div class="underline1"></div>
    </div>
  </div>

<div class="container mt-5 pb-5">
  <div class="row">
    <?php
    include('functions2.php');
    ?>
  </div>
</div>



<div class="container-fluid pt-5">
   <div class="row">
      <h3>FEATURE MEN's WEAR</h3>
    </div>
    <div class="row">
      <div class="underline1"></div>
    </div>
</div>
  <br>
<div class="container">
  <div class="row">
    <?php
    include('functions.php');
    ?>
  </div>
</div><!--container end-->
</div>




<?php
include("footer.php");
?>
  
</body>
</html>		