<?php
include 'init.php';
if(!isset($_SESSION['user'])){
 header ('location:watWk9.php');
}
else{
    echo "Welcome to the official page of the HJOULJ";
}
?>