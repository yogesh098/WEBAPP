<?php 
session_start();
$host="localhost";
$db="tbcl52019d";
$u = "root";
$p="";
$connection = mysqli_connect($host,$u,$p,$db) or die("Error while connecting database");
?>