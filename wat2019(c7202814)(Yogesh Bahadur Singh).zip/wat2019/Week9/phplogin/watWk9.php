<h3>Login</h3>
<?php
include 'init.php';
if(isset($_SESSION['user'])){
    echo "Welcome ".$_SESSION['user']."<br/>";
    echo"<a href=protected.php>Protected</a><br/>";
    echo"<a href=logout.php>logout</a><br/>";
}
else{
    include 'loginform.php';
}
?>