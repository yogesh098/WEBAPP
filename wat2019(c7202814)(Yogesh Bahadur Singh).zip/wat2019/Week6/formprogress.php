<!DOCTYPE html>
<html>
<head>
	<title>Week 6 Progress Check</title>
</head>
<body>
<h1>Search Form</h1>
<form method="POST"action="">
<p><Label>Location:</Label></p>
<input type="text"name="location"value="<?php if(isset($_POST['location'])){echo $_POST['locaation'];}?>"/>
<P><Label>Category:</Label></P>
<select name="type">
<option value="please Select">Please select</option>
<option value="Hotel"<?php echo(isset($_POST['type'])&& $_POST['type']=="Hotel")?'selected="selected"': '';?>>Hotel</option>
<option value="Guest House"<?php echo(isset($_POST['type'])&& $_POST['type']=="Guest House")?'selected="selected"': '';?>>Guest House</option>
<option value="Rental"<?php echo(isset($_POST['type'])&& $_POST['type']=="Rental")?'selected="selected"': '';?>>Rental</option>
</select>
<input type="submit" value="submit"name="submit"/>
</form>
<?php
if(isset($_POST['submit'])){
if($_POST['Location']!=""){
$location=$_POST['location'];
$location=filter_var($location,FILTER_SANITIZE_STRING);
if(isset($_POST['type'])&& $_POST['type']!="please select"){
$type=$_POST['type'];
echo"Location is <i>$location</i>and";
echo"type of residence is <i>$type</i>.";
}
else{
echo"please select a category.";
}
}
else{
echo"error,Location is empty.";
}
}
?>
</body>
</html>