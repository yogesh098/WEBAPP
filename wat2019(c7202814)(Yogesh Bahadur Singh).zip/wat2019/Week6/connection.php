<?php
$host="localhost";
$u="root";
$p="";
$db="wat2019";
$conn=mysqli_connect($host,$u,$p,$db)
or die("Error while connecting database");
?>