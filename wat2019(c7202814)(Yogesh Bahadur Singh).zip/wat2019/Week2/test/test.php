<!DOCTYPE html> 
<html lang="en">  
<head>   
	<title>My web document</title>   
	<link href="Test.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="test.css">  
	<link rel="stylesheet" type="text/css" href="message.php">
</head>  
<body>   
	<section id="container">    
		<p>     Below is a PHP generated message:-    
		</p>    
		 
		<?php
// Print some words to the screen 
print "If all is well then this message will be seen when you browse this web page"; 
?>   
	</section>  
	<?php    
		include "message.php;    
		?>
</body> 
</html> 