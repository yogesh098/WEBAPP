<?php

//Make connection to database
include 'connection.php';
//Display heading
echo '<h2>Select ALL from the Customer Table</h2>';
//run query to select all records from customer table
$query="SELECT * FROM Customer";
//store the result of the query in a variable called $result
$result=mysqli_query($connection, $query);
//Use a while loop to iterate through your $result array and display
//the first name, last name and email for each record
echo"<table border=1 cellpadding=5 cellspacing=5 width=300>";
echo"<style>table{border-collapse:collapse}</style>";
echo"<tr>";
echo"<th>FirstName</th>";
echo"<th>LastName</th>";
echo"<th>Email</th>";
echo"<th>Age</th>";
echo"</tr>";
while ($row=mysqli_fetch_assoc($result)){
    echo"<tr>";
    echo"<td>".$row['FirstName']."</td>";
    echo"<td>".$row['LastName']."</td>";
    echo"<td>".$row['Email']."</td>";
    echo"<td>".$row['Age']."</td>";
    echo"</tr>";
}
echo"</table>";
//Customer with age>22
echo '<h2>Select ALL from the Customer Table with Age > 22</h2>';
$query="SELECT * FROM Customer where age>22";
$result=mysqli_query($connection, $query);
echo"<table border=1 cellpadding=5 cellspacing=5 width=300>";
echo"<tr>";
echo"<th>FirstName</th>";
echo"<th>LastName</th>";
echo"<th>Email</th>";
echo"<th>Age</th>";
echo"</tr>";
while ($row=mysqli_fetch_assoc($result)){
    echo"<tr>";
    echo"<td>".$row['FirstName']."</td>";
    echo"<td>".$row['LastName']."</td>";
    echo"<td>".$row['Email']."</td>";
    echo"<td>".$row['Age']."</td>";
    echo"</tr>";
}
echo"</table>";
//Female Customer with age>=22
echo '<h2>Select Females from the Customer Table with Age >=22</h2>';
$query="SELECT * FROM Customer where age>=22 having gender='F'";
$result=mysqli_query($connection, $query);
echo"<table border=1 cellpadding=5 cellspacing=5 width=300>";
echo"<tr>";
echo"<th>FirstName</th>";
echo"<th>LastName</th>";
echo"<th>Email</th>";
echo"<th>Age</th>";
echo"</tr>";
while ($row=mysqli_fetch_assoc($result)){
    echo"<tr>";
    echo"<td>".$row['FirstName']."</td>";
    echo"<td>".$row['LastName']."</td>";
    echo"<td>".$row['Email']."</td>";
    echo"<td>".$row['Age']."</td>";
    echo"</tr>";
}
echo"</table>";
//Male Customer list by age descending
echo '<h2>Select Males from the Customer Table list by age descending</h2>';
$query="SELECT * FROM Customer where gender='M' order by age desc";
$result=mysqli_query($connection, $query);
echo"<table border=1 cellpadding=5 cellspacing=5 width=300>";
echo"<tr>";
echo"<th>FirstName</th>";
echo"<th>LastName</th>";
echo"<th>Email</th>";
echo"<th>Age</th>";
echo"</tr>";
while ($row=mysqli_fetch_assoc($result)){
    echo"<tr>";
    echo"<td>".$row['FirstName']."</td>";
    echo"<td>".$row['LastName']."</td>";
    echo"<td>".$row['Email']."</td>";
    echo"<td>".$row['Age']."</td>";
    echo"</tr>";
}
echo"</table>";
//All customers with 'a' in the first name
echo '<h2>Select all customers with \'a\' in the first name</h2>';
$query="SELECT * FROM Customer where Firstname like '%a%'";
$result=mysqli_query($connection, $query);
echo"<table border=1 cellpadding=5 cellspacing=5 width=300>";
echo"<tr>";
echo"<th>FirstName</th>";
echo"<th>LastName</th>";
echo"<th>Email</th>";
echo"<th>Age</th>";
echo"</tr>";
while ($row=mysqli_fetch_assoc($result)){
    echo"<tr>";
    echo"<td>".$row['FirstName']."</td>";
    echo"<td>".$row['LastName']."</td>";
    echo"<td>".$row['Email']."</td>";
    echo"<td>".$row['Age']."</td>";
    echo"</tr>";
}
echo"</table>";
?>