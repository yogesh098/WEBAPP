<!DOCTYPE HTML>
<html>
    <head>
        <title>Php Query</title>
</head>
<body>
    <form method="POST" action="insertRecord.php">
        <fieldset>
            <legend>Enter Customer Details</legend>
            <label for ="Firstname">First Name:</label>
            <input type="text" name="fname"/><br/>
            <label for ="Surname">Surname:</label>
            <input type="text" name="sname"/><br/>
            <label for ="Email">Email:</label>
            <input type="text" name="email"/><br/>
            <label for ="Password">Password:</label>
            <input type="password" name="password"/><br/>
            <label for ="gender">Gender:</label>
            <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            </select><br/>
            <label for ="age">Age:</label>
            <input type="number" name="age"/><br/>
            <input type="submit" value="Submit" name="Submit"/>
        </fieldset>
    </form>
    <?php
include 'selectRecord.php';
?>
</body>
    </html>
