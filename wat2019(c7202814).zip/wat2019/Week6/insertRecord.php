<?php
include('connection.php');
if(isset($_POST['Submit'])){
    $fname=$_POST['fname'];
    $sname=$_POST['sname'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $gender=$_POST['gender'];
    $age=$_POST['age'];
    if($fname!=""&&$sname!=""&&$email!=""&&$pass!=""&&$age!=""){
        //SQL statement
$query = "INSERT INTO customer(FirstName,LastName,Email,Password,Gender,Age) VALUES ('$fname','$sname','$email','$pass','$gender',$age)";
//connecting DB
//making query and execute
$qry = mysqli_query($connection,$query);
if($qry){
    echo"Data inserted Successfully";
    }
    else{
    echo"Something wrong";
    }
}
else{
    echo"All fields required";
}
}
?>