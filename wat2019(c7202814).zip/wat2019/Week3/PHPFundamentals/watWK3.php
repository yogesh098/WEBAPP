<!DOCTYPE html>
<html>
<head>
	<title>watWk3</title>
</head>
<body>
<h1>Yogesh Bahadur Singh (c7202814)</h1>
<h3>Variable</h3>


<?php
	echo "“most programmers say it’s better to use ‘echo’ rather than ‘print’” says who?<br/>";
	echo "<br/>";

	$name = "David";

	$age = "12";

	echo "Hi my name is " . $name . " and I am " . $age . " years old.<br/>";
	echo "<br/>";
	//<?php 
  

$name = 'David';// First String 
$age = "12";// now $a contains "HelloWorld!" 
echo "Mi nombre es $name  y tengo $age anos de edad <br/>" ;// Print The String $a 
echo "<br/>";
echo"<h1>Functions</h1>";
//gettype()returns the kins of .. 
echo gettype($name); 
echo '<br />'; 
//strlen() returns.. 
echo strlen($name); 
echo '<br />'; 
//strtoUpper()returns.. 
echo strtoUpper($name);
echo '<br/>';
echo "<br/>";
?>
<h1>Arithmetic</h1>
<?php
$num1 = 9;
$num2 = 12;
echo("num1 = $num1 <br />");
echo("num2 = $num2 <br />");
echo("num1 x num2 =" .$num1 * $num2. "<br />");
echo("num1 as a percentage of num2 = ".(($num1/$num2)*100)." % <br />");
echo("num2 divided by num1 = ".floor($num2/$num1)." remainder ".fmod($num2,$num1)." <br />");
echo("<h3>Calculate height in feet and inches</h3>");
echo("Name:David <br />");
echo("Age:12 <br />");
$height=1.8;
echo("Height in Meters:$height <br />");
$height_inches=($height*100)/2.54;
$height_feet=($height*100)/(2.54*12);
echo("Height in Feet and inches:".floor($height_feet)."ft ".floor(fmod($height_inches,12))."ins");
?>

<h1>Section</h1>
<?php
  $day = date('l'); //that is a lower case L 
 echo 'it\'s '.$day; 
date_default_timezone_set('UTC');// set the default timezone to use. Available since PHP 5.1
echo "<br/>";
echo date("l");// Prints something like: Monday
echo "<br/>";
echo date('l jS \of F Y h:i:s A');// Prints something like: Monday 8th of August 2005 03:12:46 PM
echo "<br/>";
echo "<br/>";
$day = date('l');//"wednesday";
echo 'it\'s' . $day . "<br/>";

if ($day == "Wednesday"){
	echo "it's  midweek.";
}
else{
	echo"it's not midweek";
}
echo "<br/>";
echo "<br/>";
?>

<?php
$today = date("H:i:s");//date_default_timezone_set('UTC');s
echo "it's "  . $today . "<br />";
if($today < "12:00:00"){
	echo "Good Morning !!";
}
elseif ($today <= "12"  &&  "18") {
	echo "Good Afternoon !!";
}
else{
	echo "Good Night !!";
}
echo "<br/>";
echo "<br/>";
?>


<?php
    $strstrlen = "This is strlen tutorial!";
    $intlen = "The length of string is :" .strlen($strstrlen);
    echo $intlen;
    echo "<br>";
?>
<?php
$password = "password";
if(strlen($password)>4&&strlen($password)<10){
    echo("Password length is valid");
}
if($password == "password" || $password == "username"){
    echo("<br/>Password length is valid");
}
else{
echo("<br/>Password length is invalid invalid");
};
echo("<h2>Ticket Company</h1>");
$ticket = 25;
$ag = 15;
$member = "TRUE";
#SMALLER THAN 12 BUT NO MEMBER
if($ag<12 && $member != "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:No<br/>");
    echo("Final Ticket Price: £".($ticket*50)/100)."<br/>";
}
#SMALLER THAN 12 AND MEMBER
elseif($ag<12 && $member == "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:Yes<br/>");
    echo("Final Ticket Price: £".($ticket*40)/100)."<br/>";
}
#SMALLER THAN 18 OR GREATER THAN 65 BUT NO MEMBER
elseif(($ag<18 || $ag>65) && $member != "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:No<br/>");
    echo("Final Ticket Price: £".($ticket*75)/100)."<br/>";
}
#SMALLER THAN 18 OR GREATER THAN 65 AND MEMBER
elseif(($ag<18 || $ag>65) && $member == "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:Yes<br/>");
    echo("Final Ticket Price: £".($ticket*65)/100)."<br/>";
}
#GREATER THAN 18 AND SMALLER THAN 65 BUT NO MEMBER
elseif($ag>18 && $ag<65 && $member != "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:Yes<br/>");
    echo("Final Ticket Price: £$ticket<br/>");
}
#GREATER THAN 18 AND SMALLER THAN 65 AND MEMBER
elseif($ag>18 && $ag<65 && $member == "TRUE"){
    echo("Initial Ticket Price: £$ticket<br/>");
    echo("Age:$ag<br/>");
    echo("Member:Yes<br/>");
    echo("Final Ticket Price: £".($ticket*90)/100)."<br/>";
}
?>


</body>
</html>