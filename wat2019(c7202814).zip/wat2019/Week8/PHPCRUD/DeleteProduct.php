<?php
include('connection.php');
   if(isset($_GET['cid']))
   {
   	 $deleteID=$_GET['cid'];
   }
   $sql="DELETE FROM products WHERE product_id=$deleteID";
   mysqli_query($connection, $sql);
   if (mysqli_affected_rows($connection) > 0) {
	header('Location: watWk8.php');
   } else {
	echo "Error in query: $query. " . mysqli_error($connection);
	exit ;
   }
   
?>