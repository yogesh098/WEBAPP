<?php
include('connection.php');
if(isset($_POST['InsertProduct']))
{
		$product = $_POST['product'];
		$price = $_POST['price'];
		$image = $_POST['image'];
	if($product!=""&&$price!=""&&$image!=""){
		$sql="INSERT INTO products
		(
		product_title,product_price,product_img1
	   )
			  Values('$product','$price','$image')
			  ";	
			  echo"$sql";
	mysqli_query($connection, $sql);
	header('Location: watWk8.php');
	}
	else{
		echo "All fields required";
		exit;
	}	
}
?>