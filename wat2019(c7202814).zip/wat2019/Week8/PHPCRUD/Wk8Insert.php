<?php
include 'connection.php';
error_reporting(E_ALL);
if (isset($_POST['subEvent'])){
$name = $_POST['txtName'];
$pass = $_POST['txtCategory'];
}
$query="INSERT INTO events(eventName,eventCategory)VALUES('$name','$pass')";
mysqli_query($connection, $query);
header('location:Wk8Recap.php');
?>