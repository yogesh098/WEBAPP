<?php error_reporting(E_ALL);?>
<!DOCTYPE html>
<html>
<head>
<link type="text/css" rel="stylesheet" href=""/>
<title>Result</title>
</head>
<body>
<h1>Insert a record</h1>
<form method="post" action="Wk8Insert.php">
<input type="text" name="txtName" />
<br />
<input type="text" name="txtCategory" />
<br />
<input type="submit" value="Submit" name="subEvent" />
</form>
<?php
//display results
include 'Wk8Select.php';
?>
</body>
</html>
