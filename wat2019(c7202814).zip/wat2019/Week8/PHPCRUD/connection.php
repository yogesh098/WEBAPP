<?php
$h="localhost";
$u="root";
$p="";
$d="wat";
$connection = mysqli_connect($h, $u, $p, $d) or die("Error to Connect DB");
?>