<!DOCTYPE HTML>
<html>
<head>
    <title>Manage Products</title>
</head>
<body>
    <h1>Manage Products</h1>
    <?php
    include 'DisplayRecord.php';
    ?>
    <form method="POST" action="InsertProduct.php">
        <fieldset>
        <legend>Enter New Product Details</legend>
        <label for="ProductName">Product Name:</label>
        <input type = "text" name = "product" /><br/>
        <label for="ProductPrice">Product Price:</label>
        <input type = "text" name = "price" /><br/>
        <label for="ImageFileName">Image Filename:</label>
        <input type = "text" name = "image" /><br/>
        <input type = "submit" name="InsertProduct" />
        <input type = "reset" />
    </fieldset>    
    </form>
</body>
</html>