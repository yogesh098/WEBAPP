<!DOCTYPE HTML>
<html>
    <title>Amend Products</title>
    <body>
        <h1>Amend Products </h1>
</body>        
</form>
    </html>
<?php
include 'connection.php';
   if(isset($_GET['cid']))
   {
   	 $amendID=$_GET['cid'];
   	 $sql="SELECT * FROM products WHERE product_id=$amendID";
        $qry=mysqli_query($connection, $sql);
   	 echo "<table border=0 cellpadding=6 cellspacing=10>";
   	 echo "<form method='POST' action='UpdateProduct.php'>";
   	 while($row=mysqli_fetch_array($qry))
   	 {
   	 	echo "<tr>
            <td><input type='hidden' name='productid' value=".$row['product_id']."></td>
            </tr>
            <tr>
   	 	    <td>ProductName:</td>
            <td><input type='text' name='product' value=".$row['product_title']."></td>
            </tr>
            <tr>
            <td>ProductPrice:</td>
            <td><input type='text' name='price' value=".$row['product_price']."></td>
            </tr>
            <tr>
            <td>ProductImageName:</td>
            <td><input type='text' name='image' value=".$row['product_img1']."></td>
            </tr>
            ";
   	 }

echo "<tr><td></td><td>
    <input type='submit' name='AmendProduct' value='Amend'>
    <input type = 'reset'>
</td></tr>";
        echo "</form></table>";
    }
?>
