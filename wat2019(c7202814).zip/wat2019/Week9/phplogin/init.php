<?php 
session_start();
$host="localhost";
$db="mrshoes";
$u = "root";
$p="";
$connection = mysqli_connect($host,$u,$p,$db) or die("Error while connecting database");
?>