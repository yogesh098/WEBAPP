<?php
include 'init.php';
if(isset($_POST['subLogin'])){
    $txtUser= $_POST['txtUser'];
    $txtPass= $_POST['txtPass'];
}
$query="Select * from users where username = '$txtUser' AND password = '$txtPass'";
   $result = mysqli_query($connection, $query);
if ($result) {
    $_SESSION['user']=$txtUser;
    header ('location:watWk9.php');
    } 
    else {
        header ('location: watWk9.php');
        echo 'User not recognised';
    }

?>