<?php

include('connection.php');

$nameErr = $emailErr = $passwordErr = $genderErr = $age = ""; 

$name = $email = $password = $gender = $age = "";

if(isset($_POST['submit'])){
  if (empty($_POST['name'])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["password"])) {
    $passwordErr= "Password is required";
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }

  if (empty($_POST["age"])) {
    $countryErr = "age is required";
  } else {
    $age = test_input($_POST["age"]);
  }

  $submit="INSERT INTO userlogin
(name, email, password, gender, age, role) VALUES ('$name','$email','$password','$gender','$age',2)";
$run_submit = mysqli_query($con,$submit);
header("location:login.php");
//echo $run_submit;
//exit();

}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/regcss.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="../js/bootstrap.js"></script>
	<title>Registration</title>
</head>
<body>

 	<div class="container">
		<div class="row">
			<div class="col-md-7">
				<h1 class="text-left">Registration Form</h1>
				<p class="text-left">A Quick brown fox jumps over the lazy dog.</p>
			</div>
			<div class="col-md-5">
			 <!--make 2 columns of 6-->
			 <div class="row">
			 	<div class="col-md-6">
			 		<h3>Registration Form</h3>
			 	</div>
			 	<div class="col-md-6">
			 		<span class="glyphicon-pencil"></span>
			 	</div>
			 	<hr>
			 	<!--close-->

		 	<div class="container">
        <form method="post" action="">
          <div class="row">
            <div class="col-md-3">
            <label class="label col-md-2 control-label">Name</label></div>
            <div class="col-md-9">
              <input type="text" class="form-control" name="name" placeholder="Enter Your Full Name">
            </div>
          </div>

          <div class="row">
            <div class="col-md-3">
            <label class="label col-md-2 control-label">Email</label></div>
            <div class="col-md-9">
             <input type="Email" class="form-control" name="email" placeholder="Enter your E-mail">
            </div>
          </div>

        <div class="row">
          <div class="col-md-4">
          <label class="label col-md-2 control-label">Password</label></div>
          <div class="col-md-8">
            <input type="Password" class="form-control" name="password" placeholder="Passsword">
          </div>
        </div>
       
        
        <div class="row">
          <div class="col-md-3">
          <label class="label col-md-2 control-label">Gender</label></div>
          <div class="col-md-9">
            <input type="radio" name="gender" value="male"><small> Male</small>
            <input type="radio" name="gender" value="female"><small> female</small>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
          <label class="label col-md-2 control-label">Age</label>
        </div>
          <div class="col-md-8">
            <select name="age" class="form-control">
              <option value=''>AGE</option>
              <option value="18">18</option>
              <option value="19">19</option>
              <option value="20">20</option>
              <option value="21">21</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8">
          <input type="checkbox" required="required"><small>  Terms and Conditions</small>
        </div>
        </div>
        <div class="form-group">
              <input type="submit" name="submit" value="submit" class="btn btn-primary form-control">
        </div>
        <a href="login.php"><div class="btn btn-warning" style="margin: 30px;">Back To login</div></a>
      </form>
      </div>
       </div>
    </div>
  </div>
</div>  

</body>
</html>