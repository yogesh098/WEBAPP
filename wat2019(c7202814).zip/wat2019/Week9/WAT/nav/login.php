<?php

include('connection.php');

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/regcss.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="../js/bootstrap.js"></script>
  <title>login form</title>
</head>
<body>

  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <h1 class="text-left">LOGIN FORM</h1>
        <p class="text-left">A Quick brown fox jumps over the lazy dog.</p>
      </div>
      <div class="col-md-5">
       <!--make 2 columns of 6-->

       <div class="row">
        <div class="col-md-6">
          <br>
          <h3>LOGIN FORM</h3>
        </div>

        <div class="col-md-6">
          
        </div>
        <hr>
        <!--close-->
        <br><br><br>
               <form  method="POST">
                  <div class="container">
                    <div class="row">
                      <label class="label col-md-2 control-label"></label><br>
                      <div class="col-md-10">
                        <input type="email" class="form-control" name="email" placeholder="Enter your email" value="<?php echo isset($_SESSION['email']) ?$_SESSION['email'] : '' ?>"/>
                      </div>
                    </div>

                    <br><br><br>

                    <div class="row">
                      <label class="label col-md-2 control-label"></label><br>
                      <div class="col-md-10">
                        <input type="password" class="form-control" name="password" placeholder="Enter Your Password" /><br><br><br>
                        <input type="checkbox"><small>  Remember me</small><br>
                        <input type="checkbox" required="required"><small>  Terms and Condition</small>
                        <br><br><br>
                      </div>
                    </div>
                    <div class="form-group">
                      <?php
                      if(isset($SESSION['login'])){
                      echo '<input type="submit" name="logout" value="logout" class="btn btn-primary form-control">';  
                                            }                    
                      echo '<input type="submit" name="login" value="LOGIN" class="btn btn-primary form-control">';
                      ?>
                    </div>
                      <br></a>
                      <div class="row">
                        <div class="col-md-6">
                    <a href="password_forgot.php" class="btn btn-light pm-5 "> forgot my password ?</a><br></div>
                    <div class="col-md-6">
                    <a href="registration.php" class="btn btn-light text-center light"> Register a new membership</a><br>
                    </div>
                  </div>
                </form>
              </div>
            </div>
    </div>
  </div>
 
</body>
</html>