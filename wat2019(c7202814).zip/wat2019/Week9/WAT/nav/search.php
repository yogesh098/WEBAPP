<?php
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script type="text/javascript" src="../js/proper.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <title>Mr.SHOES</title>
</head>
<body>
<div class="container-fluid bg-dark header-top">
  <div class="container">
    <div class="row text-light pt-2 pb-2">

      <div class="col-md-3">
         <a href="www.facebook.com"><img  src="../admin/images/facebook.png" width="40" height="40" alt="Facebook-logo"></a>
         <a href="www.instagram.com"><img src="../admin/images/instagram.png" width="30" height="30" alt="Instagram-logo"></a>
        <a href="www.twiter.com"> <img src="../admin/images/twitter.png" width="40" height="40" alt="Instagram-logo">
      </div>
      <div class="col-md-4">
        
      </div>
    
      <div class="col-md-2">
        <?php
        if(isset($_SESSION['name'])){
        echo"<a href='./customer/my_account.php'>
              <i class='fa fa-user-o' aria-hidden='true'></i>".$_SESSION['name']."</a>";
      }
      else{
        echo"<a href='login.php'>
              <i class='fa fa-user-o' aria-hidden='true'></i>Account</a>";
      }
      ?>
      </div>
      <?php 
      if (isset($_SESSION['name'])) {
         echo" <div class='col-md-2''><a href='getfavlist.php'>
        <i class='fa fa-cart-plus' aria-hidden='true'></i>
        My favourite </a>
      </div>";
      }
       ?>

      <div class="col-md-1">
      <?php
      if(isset($_SESSION['name'])){
       echo "<a href='logout.php'><button class='btn btn-outline-success my-2 my-sm-0' type='submit'>Logout</button></a>"; 
      }
      else{
        echo "<a href='login.php'><button class='btn btn-outline-success my-2 my-sm-0' type='submit'>LOGIN</button></a>";
            
      }  
      ?> 
       </div>
      </div>
    </div>
</div>

<div class="container-fluid bg-black">
  <nav class="container navbar navbar-expand-lg navbar-dark bg-black">
  <a class="navbar-brand" href="../index.php">
    <img src="../admin/images/mr.png" width="40" height="40" alt="Shoes-logo">MR.SHOES</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="col-md-6 col-sm-6" >
  <div class="collapse navbar-collapse" id="navbarSupportedContent" style="margin-left:70px;">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="../index.php">HOME <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          CATEGORY
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="kids.php">KIDS</a>
          <a class="dropdown-item" href="womens.php">WOMENS</a>
          <a class="dropdown-item " href="men.php">MENS</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../about.php">ABOUT</a>


      </li>
    </ul>
  </div>
</div>
  <div class="col-md-6">
    <form class="form-inline my-2 my-lg-0" action="search.php" method="POST">
      <input class="form-control mr-sm-1" name="searchword" placeholder="Enter word here" aria-label="Search" style="margin: 10px;">
       <input type="submit" value="Search" name="search" style="border-radius:5px;background-color:white;color:black;padding:5px;">
    </form>
  </div>
</nav>
</div>
       <?php 
      // include('nav/connection.php');
       if(isset($_POST['search'])){
        $search  = $_POST['searchword'];
                $get_products="SELECT * FROM products where product_price LIKE '%$search%' OR product_title LIKE '%$search%' OR product_keyword LIKE '%$search%' OR product_brand LIKE '%$search%'";
                $run_products=mysqli_query($con,$get_products);
                if(mysqli_num_rows($run_products)!=0){
                while ($run_product=mysqli_fetch_assoc($run_products)) {
                  $id = $run_product['product_id'];
                  echo"<div class='col-md-3'><div class='card'>";
                  if($run_product['product_keyword']=="mens"){
                 echo"<img src='../admin/images/mens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                  if($run_product['product_keyword']=="womens"){
                 echo"<img src='../admin/images/womens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                  if($run_product['product_keyword']=="kids"){
                 echo"<img src='../admin/images/kids/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                           if(isset($_SESSION['name'])){  
                            echo"<a href='getfavlist.php?product_id=$id' class='btn btn-success'><i class='fa fa-favourite-plus' aria-hidden='true' name='add_to_favourite'></i>Add To favourite</a>
                                ";
                            }
                 echo"</div></div>";
            
          }
  
                }                
          else{
            echo"<h1>No results found</h1>";
          }
        }
         ?>

         
         <footer>
  <div class="container-fluid pt-5 bg-dark text-light">
      <div class="row">
        <div class="col-md-3">
          <div class="row">
            <h5>Meta</h5>
          </div>
          <div class="row mb-4">
            <div class="underline bg-light" style="width: 50px"></div>
          </div>
          <p><i class="fa fa-chevron-right" aria-hidden="true"></i> Register</p>
          <p><i class="fa fa-chevron-right" aria-hidden="true"></i> Log In</p>
          <p><i class="fa fa-chevron-right" aria-hidden="true"></i> Enter RSS</p>
          <p><i class="fa fa-chevron-right" aria-hidden="true"></i> Comments</p>
          <p><i class="fa fa-chevron-right" aria-hidden="true"></i> Webseotips</p>
        </div>
        
        
        <div class="col-md-3">
          <div class="row">
            <h5>Recent Posts</h5>
          </div>
          <div class="row mb-4">
            <div class="underline bg-light" style="width: 50px"></div> 
          </div>
          <div class="row">
            <div class="media">
              <img src="../admin/images/slider4.jpg" class="img-fluid" alt="media-image">
              <div class="media-body ml-2">
                <h6>ackets For The Soul. What Color Is Yours?</h6>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="media">
              <img src="../admin/images/slider4.jpg" class="img-fluid" alt="media-image">
              <div class="media-body ml-2">
                <h6>Best Fabrics For Your Dream Dress!</h6>
              </div>
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3">
          <div class="row">
            <h5>About</h5>
          </div>
          <div class="row mb-4">
            <div class="underline bg-light" style="width: 50px"></div> 
          </div>
          <div class="row">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel inventore quis harum mollitia ex esse obcaecati deserunt alias fuga quia.<br>Vel inventore quis harum mollitia.</p>
          </div>
        </div>
        
        <div class="col-md-3">
          <div class="row">
            <h5>Tags</h5>
          </div>
          <div class="row mb-4">
            <div class="underline bg-light" style="width: 50px"></div> 
          </div>
          <button class="btn btn-outline-light">autunm</button> <button class="btn btn-outline-light">Dress</button> <button class="btn btn-outline-light">ladice</button> <button class="btn btn-outline-light">black dressunm</button> <button class="btn btn-outline-light">modern dress</button>
        </div>
      </div>
  </div> 
</footer>
