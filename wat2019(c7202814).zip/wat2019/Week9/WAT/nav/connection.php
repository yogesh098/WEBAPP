<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db = "mrshoes";

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " .mysqli_connect_error());
}

if(isset($_POST['login']))
  {
$email=$_POST['email'];
$pass=$_POST['password'];

$query="select * from userlogin where email='$email' and password='$pass'";
$qry=mysqli_query($con,$query);

$c=mysqli_num_rows($qry);

if($c==1)
{
while($row=mysqli_fetch_array($qry))
{
  $role=$row['role'];
  $_SESSION['name']=$row['name'];

  if($role==1)
{
  $_SESSION['admin']=$email;
header('location:../admin/index.php');

}
else
{
header('location:../index.php');
}
  }

}

else
{
 echo "INVALID LOGIN";
}

}

?>