<?php

$product_id=$_GET["product_id"];
$set=setcookie("myfav[$product_id]", $product_id, time()+(60*60*24*30), "/");
if (!$set) {
	echo"Not added";
}
else
	echo "Cookie added";
//echo "<a href='getfavlist.php'?product_id=$product_id>GET LIST of FAV</a>";
header('location: getfavlist.php')



?>