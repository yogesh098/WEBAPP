<?php
$product_id=$_GET['product_id'];
setcookie("myfav[$product_id]", $product_id, time()-(1), "/");
echo "Cookie Deleted";
echo "<a href='getfavlist.php'?product_id=$product_id>GET LIST of FAV</a>";
?>