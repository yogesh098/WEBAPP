<?php  
include('header.php');
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <title>fav</title>
</head>
<body>

<?php 

  $con=mysqli_connect('localhost','root','','mrshoes');
  if (isset($_COOKIE['myfav'])) {
   echo"<div class='container'>
   <table class='table table-hover table-bordered table-striped'>
                      <tr>
                        <th>Product ID</th>
                        <th>Product Image Name</th>
                        <th>Product Title</th>
                        <th>Product Price</th>
                        <th>Product Delete</th>
                      </tr>";
    foreach ($_COOKIE['myfav'] as $product_id => $value) {
    $result="SELECT * FROM products WHERE product_id='$value'";
    $run_products=mysqli_query($con,$result);      
    while ($run_product=mysqli_fetch_assoc($run_products)){
      $product_id=$run_product['product_id'];
      $product_img1=$run_product['product_img1'];
      $product_title=$run_product['product_title'];
      $product_price=$run_product['product_price'];
       
                      echo"<tr>
                        <td>$product_id</td>
                        <td>$product_img1</td>
                        <td>$product_title</td>
                        <td>product_price</td>
                     <td><a href='deletefav.php'?product_id=$product_id name='delete'>DELETE</a></td>
                          </tr>
            </table>
          </div>"; 
                }
                 }
      }
                 
                ?>



</body>
</html>