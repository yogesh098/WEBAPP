<?php 
			// include('nav/connection.php');
                $con=mysqli_connect('localhost','root','','mrshoes');
                $get_products="SELECT * FROM products limit 10,4";

                $run_products=mysqli_query($con,$get_products);
                

                while ($run_product=mysqli_fetch_assoc($run_products)) {
                  $up = $run_product['product_id'];
                	echo"<div class='col-md-3'><div class='card'>";
                  if($run_product['product_keyword']=="womens"){
                 echo"<img src='admin/images/womens/".$run_product['product_img1']."' class='card-img-top'></a>";
                 echo"
                  <h5>".$run_product['product_title']."</h5></a>";
                  echo"<p class='list-price text-danger'>List Price:<s>$'".$run_product['product_list_price']."'</s></p>";
                 echo"<p class='price'>Our Price: $'".$run_product['product_price']."'</p>";                  
                  }
                           if(isset($_SESSION['name'])){  
                           	echo"<button type='button' class='btn btn-success'>
                                 <a href='nav/addtofav.php?product_id=$up'><i class='fa fa-cart-plus' aria-hidden='true'></i>Add To Cart</a>
                                 </button>";
                            }
                 echo"</div></div>";
            
          }
        
         ?>