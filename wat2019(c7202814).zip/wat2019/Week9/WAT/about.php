<?php
include("nav/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <title>Mr.SHOES</title>
</head>
<body>
<div class="container-fluid bg-gradient-warning header-top">
  <div class="container">
    <div class="row text-light pt-2 pb-2">

      <div class="col-md-3">
      <a href="www.facebook.com"> <img src="admin/images/facebook.png" width="40" height="40" alt="Facebook-logo"></a>
       <a href="www.instagram.com">  <img src="admin/images/instagram.png" width="30" height="30" alt="Instagram-logo"></a>
        <a href="www.twiter.com"> <img src="admin/images/twitter.png" width="40" height="40" alt="Instagram-logo"></a>
      </div>
      <div class="col-md-4">
        
      </div>
    
      <div class="col-md-2">
        <?php
        if(isset($_SESSION['name'])){
        echo"<a href='customer/my_account.php'>
              <i class='fa fa-user-o' aria-hidden='true'></i>".$_SESSION['name']."</a>";
      }
      else{
        echo"<a href='nav/login.php'>
              <i class='fa fa-user-o' aria-hidden='true'></i>Account</a>";
      }
      ?>
      </div>
      <?php 
      if (isset($_SESSION['name'])) {
         echo" <div class='col-md-2''><a href='nav/getfavlist.php'>
        <i class='fa fa-cart-plus' aria-hidden='true'></i>
        My favourite </a>
      </div>";
      }
       ?>

      <div class="col-md-1">
      <?php
      if(isset($_SESSION['name'])){
       echo "<a href='nav/logout.php'><button class='btn btn-outline-success my-2 my-sm-0' type='submit'>Logout</button></a>"; 
      }
      else{
        echo "<a href='nav/login.php'><button class='btn btn-outline-success my-2 my-sm-0' type='submit'>LOGIN</button></a>";
            
      }  
      ?> 
       </div>
      </div>
    </div>
</div>

<div class="container-fluid bg-black">
  <nav class="container-fluid navbar navbar-expand-lg navbar-dark bg-black">
  <a class="navbar-brand" href="index.php">
    <img src="admin/images/mr.png" width="40" height="40" alt="Shoes-logo">MR.SHOES</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="col-md-2">
    
  </div>

  <div class="col-md-6 col-sm-6" >
  <div class="collapse navbar-collapse" id="navbarSupportedContent" style="margin-left:70px;">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">HOME <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          CATEGORY
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="nav/kids.php">KIDS</a>
          <a class="dropdown-item" href="nav/womens.php">WOMENS</a>
          <a class="dropdown-item " href="nav/men.php">MENS</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="about.php">ABOUT</a>


      </li>
    </ul>
  </div>
</div>
  <div class="col-md-4">
   <form class="form-inline my-2 my-lg-0" action="search.php" method="POST">
      <input class="form-control mr-sm-1" name="searchword" placeholder="Enter word here" aria-label="Search" style="margin: 10px;">
       <input type="submit" value="Search" name="search" style="border-radius:5px;background-color:white;color:black;padding:5px;">
    </form>
  </div>
</nav>
</div>

<div class="container-fluid">
<h1>About My Shoes</h1>
<div class="row">
	<div class="col-md-8">
	<p>This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market. </p>
</div>
<div class="col-md-4">
	<img src="admin/images/mr.png" alt="Mr.Shoes-logo">
</div>
	
</div><br>
<h1>LISTEN SONG</h1><br>
<div class="row">

	<div class="col-md-3">
		<iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY?playlist=tgbNymZ7vqY&loop=1">
</iframe>
	</div>
	<div class="col-md-9">
		<p>
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		
	</p>
	<p>
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		
	</p>
	<p>
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		
	</p>
	</div>
	
	
</div><br><br>
<p>
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		This is the place where yoiu can find different types of shoes and have fun making shooping in this website where you will love shooping of these lovely and best product then other in tha market.
		
	</p>

</div>

		<div class="container">
			 <h2>Contact Us on</h2> <br>
			 Gmail    : myshoes@gmail.com<br>
		Facebook : Mr.Shoes <br>
		Website  : www.mrshoes.com<br>
		</div>
		
	
<?php
include("footer.php");
?>
</body>
</html>