<?php
$con=mysqli_connect('localhost','root','','mrshoes');
if(isset($_GET['id'])){
    $product_id=$_GET['id'];
    $qry="select * from userlogin where id='$user_id'";
    while($row_pro=mysqli_fetch_array(mysqli_query($con,$qry))){		
		$id=$row_pro['id'];
		$name=$row_pro['name'];
		$email=$row_pro['email'];
		$password=$row_pro['password'];
		$gender=$row_pro['gender'];
		$age=$row_pro['age'];
    $role=$row_pro['role'];
        break;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Activity | Visit Nepal 2020</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../admin/includes/styles.css" />
</head>
<body>

<div class="container">
<div id='addProd'><h4>Update Activity</h4>
<form action='update1.php' method='POST' enctype='multipart/form-data'>

<table id="addTable" cellspacing="10">
<input type="hidden" name="id" value="<?php echo $user_id; ?>"/>
    <tr>
        <td align="left"><b>Name: </b></td>
        <td><input type="text" name="name" placeholder="Product Title" value="<?php echo '$name'; ?>"required/></td>
    </tr>
    <tr>
        <td align="left"><b>email</b></td>
        <td><input type="text" name="email" value="<?php echo '$email'; ?>" required/></td>
       
    </tr>
    <tr>
        <td align="left"><b>password:</b></td>
        <td><input type="text" name="password" value="<?php echo '$password'; ?>" required/></td>
    </tr>
    <tr>
        <td align="left"><b>gender</b></td>
        <td><textarea name="gender" cols="40" rows="10" value="<?php echo '$gender'; ?>"required></textarea></td>
    </tr>
    <tr>
        <td align="left"><b>age</b></td>
        <td><input name="age" cols="40" rows="10" value="<?php echo '$age'; ?>"required></input></td>
    </tr>
    <tr>
        <td align="left"><b>role</b></td>
        <td><input name="role" cols="40" rows="10" value="<?php echo '$role'; ?>"required></input></td>
    </tr>
    <tr align="center">
    <td colspan="2"><input type="submit" name="submit" value="Submit"/></td>
    </tr> 

    </table>
</form>
</div>


</div>
</div>    
</body>
</html>




<?php
if(isset($_POST['submit'])){

//taking the text input from the fields
$id=$_POST['id'];
$name=$row_pro['name'];
$email=$row_pro['email'];
$password=$row_pro['password'];
$gender=$row_pro['gender'];
$age=$row_pro['age'];
$role=$row_pro['role'];       


//adding the data into the database
$update_product="update products (product_img1,name,email, password, gender,age,role) values ('$product_img1','$name','$email','$password','$gender','$age','$role') where id='$user_id'";
$updateprod=mysqli_query($con, $update_product);

if($updateprod){
	echo "<script>alert('Activity updated!')</script>";
	echo"<script> window.location='../products.php'; </script>";
}	
	
}
?>