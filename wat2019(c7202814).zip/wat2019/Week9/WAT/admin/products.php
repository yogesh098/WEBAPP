<?php
include('includes/connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script>tinymce.init({selector:'textarea'});</script>
	<title>admin</title>
</head>
<body>
	<div class="row"><!--row start-->
		<div class="col-lg-12">
			<div class="breadcrumb">
				<li class="active">
					<l class="fa fa-dashboard"></l>
					Dashboard / Product
				</li>
				
			</div>
			
		</div>
		
	</div><!--row end-->

	<h1>ADMIN CONTROL PANEL</h1>
		<div class="container">
</div>
		
	</form>
    </div>
    </div>



  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">ADMIN PANEL </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark" >Dashboard</a>
        <a href="products.php" class="list-group-item list-group-item-action bg-dark active">Products</a>
        <a href="#" class="list-group-item list-group-item-action bg-dark">Profile</a>
        <a href="../index.php" class="list-group-item list-group-item-action bg-light">SHOP</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    

    <div class="container">
    <div class="row">
      <div class="col-lg-9">
        <h3>IF YOU WANT TO INSERT PRODUCTS THEN PLEASE CLICK IT !!</h3>
      </div>
      <div class="col-lg-3">
      <a href="insert_product.php" class="btn btn-primary" role="button">Insert Product</a>
      </div>
    </div>
    <br><br><br>
    <?php
    include("includes/table_display.php");
    ?>
    
  </div>



 
  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>