<?php
include('includes/connection.php');
?>

<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script>tinymce.init({selector:'textarea'});</script>

	<title>Insert Product</title>
</head>
<body>
<div class="container-fluid bg bg-secondary">
	<h1>ADMIN CONTROL PANEL</h1>
</div>
	<div class="row"><!--row start-->
		<div class="col-lg-12">
			<div class="breadcrumb">
				<li class="active">
					<l class="fa fa-dashboard"></l>
					Dashboard / Products /Insert Product
				</li>
			</div>			
		</div>		
	</div><!--row end-->


  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Insert Products </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark" >Dashboard</a>
        <a href="insert_product.php" class="list-group-item list-group-item-action bg-dark active">Insert Products</a>
        <a href="#" class="list-group-item list-group-item-action bg-dark">Profile</a>
        <a href="../index.php" class="list-group-item list-group-item-action bg-light">SHOP</a>
      </div>
    </div>

  
<div class="container"><!--Container start-->
	<div class="row"><!--row start-->
		<div class="col-md-3">
			
		</div>
		<div class="col-lg-6">
			<div class="panael panel-deafault">
				<div class="panel-heading"><!--panel heading start-->
					<h3><i class="fa a-money fa-w"></i>Insert Product</h3>
				</div><!--panel heading end-->
				<div class="panel-body">
					<form class="form-horizontal" method="post" enctype="multipart/form-data">

						<div class="form-group">
							<label class="col-md-3" control-label>Product Title</label>
							<input type="text" name="product_title" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-4" control-label>Product Image 1</label>
							<input type="file" name="product_img1">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product List Price</label>
							<input type="text" name="product_list_price" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Price</label>
							<input type="text" name="product_price" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Description</label>
							<textarea name="product_desc" class="form-control" rows="6" cols=""></textarea>
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Keyword</label>
							<input type="text" name="product_keyword" class="form-control" required="">
						</div>

						<div class="form-group">
							<label class="col-md-3" control-label>Product Brand</label>
							<input type="text" name="product_brand" class="form-control" required="">
						</div>

						<div class="form-group">
							<input type="submit" name="submit" value="Insert Product" class="btn btn-primary form-control">
						</div>
						
					</form>
				</div>
			</div>
			<div class="col-lg-3">
				
			</div>
		</div>	
	</div>
</div><!--Container end-->

<script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script><!--row end-->

</body>
</html>

<?php
if (isset($_POST['submit'])) {
	$product_title=$_POST['product_title'];
	 $product_img1 = $_FILES['product_img1']['name'];
      $file_size =$_FILES['product_img1']['size'];
      $file_tmp =$_FILES['product_img1']['tmp_name'];
      $file_type=$_FILES['product_img1']['type'];
      // $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      // 	$extensions= array("jpeg","jpg","png");

      move_uploaded_file($file_tmp,"product_images/".$product_img1);
      

	$product_list_price=$_POST['product_list_price'];
	$product_price=$_POST['product_price'];
	$product_desc=$_POST['product_desc'];
	$product_keyword=$_POST['product_keyword'];
	$product_brand=$_POST['product_brand'];

	echo "name>>>>"."$product_img1";

	$insert_product="insert into products(date,product_title,product_img1,product_list_price,product_price,product_desc,product_keyword,product_brand) values (NOW(),'$product_title','$product_img1','$product_list_price','$product_price','$product_desc','$product_keyword','$product_brand')";

	$run_product=mysqli_query($con,$insert_product);
	
	if ($run_product) {
		echo "<script>alert('Product Inserted Successfully')</script>";
		echo "<script>window.open('insert_product.php')</script>";
	}
 

}

?>