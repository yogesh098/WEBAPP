<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>



<!DOCTYPE html>
<html>
<head>
  <?php
  include('includes/connection.php');
  include('functions/functions.php');
?>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/proper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script>tinymce.init({selector:'textarea'});</script>

  <title>Insert Product</title>
  <title>Products</title>
</head>
<body>
  <h1>Products</h1>

  <div class="row"><!--row start-->
    <div class="col-lg-12">
      <div class="breadcrumb">
        <li class="active">
          <l class="fa fa-dashboard"></l>
          Dashboard /  Products
        </li>
        
      </div>
      
    </div>
  </div><!--row end-->

  <div class="container">
    <div class="row">
      <div class="col-lg-9">
        <h3>IF YOU WANT TO INSERT PRODUCTS THEN PLEASE CLICK IT !!</h3>
      </div>
      <div class="col-lg-3">
      <a href="insert_product.php" class="btn btn-primary" role="button">Insert Product</a>
      </div>
    </div>
  </div>
    <div class="row">
      <table class="table table-hover">
           <thead>
             <tr>
               <th scope="col">#</th>
               <th scope="col">First</th>
               <th scope="col">Last</th>
               <th scope="col">Handle</th>
             </tr>
           </thead>
           <tbody>
             <         tr>
               <th scope="row">1</th>
               <td>Mark</td>
              <td>Otto</td>
               <td>@mdo</td>
             </tr>
             <tr>
               <th scope="row">2</th>
               <td>Jacob</td>
               <td>Thornton</td>
               <td>@fat</td>
             </tr>
             <tr>
               <th scope="row">3</th>
               <td colspan="2">Larry the Bird</td>
               <td>@twitter</td>
             </tr>
           </tbody>
         </table>
           </div>




</body>
</html>