			 <?php 
			// include('nav/connection.php');
                $con=mysqli_connect('localhost','root','','mrshoes');
                $get_products="SELECT * FROM products LIMIT 2";

                $run_products=mysqli_query($con,$get_products);

                while ($run_product=mysqli_fetch_assoc($run_products)) {
                  $p_id = $run_product['product_id'];
                	echo"<div class='col-md-3'>
                          <div class='card'>";
                  echo"<a href='nav/mens.php'>";
                  if($run_product['product_title']=="AirMax"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top rounded-circle'></a>";
                 echo"<a href='nav/mens.php'>
                  <h5>".$run_product['product_title']."</h5></a>";                  
                  }
                  echo "</div></div>";

                echo"<div class='col-md-3'>
                          <div class='card'>";
                  echo"<a href='nav/mens.php'>";
                  if($run_product['product_title']=="Bowfin"){
                 echo"<img src='admin/images/mens/".$run_product['product_img1']."' class='card-img-top rounded-circle'></a>";
                 echo"<a href='nav/mens.php'>
                  <h5>".$run_product['product_title']."</h5></a>";                  
                  }
                  echo "</div></div>";
                }
                ?>
